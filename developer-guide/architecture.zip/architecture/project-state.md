# Project-Victory

# Project State

Versão do Documento: 1.1

Status: Oficial

---

# Objetivo

Este documento representa o estado atual oficial do desenvolvimento do Project-Victory.

Seu objetivo é permitir que qualquer nova conversa ou novo integrante compreenda imediatamente:

- o estágio atual do projeto;
- os módulos concluídos;
- os módulos em desenvolvimento;
- o próximo objetivo do Roadmap;
- as decisões arquiteturais já consolidadas.

Este documento deve ser atualizado ao final de cada Sprint.

---

# Fonte de Verdade

Este documento não substitui a documentação oficial.

Sua responsabilidade é apenas consolidar o estado atual do projeto.

A documentação oficial permanece sendo a única fonte de verdade.

---

# Sprint Atual

Nome:

Sprint de Consolidação para Transição de Conversa

Status:

CONCLUÍDA

Objetivo alcançado:

- Estrutura da documentação consolidada.
- Roadmap oficial criado.
- Estado oficial do projeto criado.
- Índice oficial da arquitetura criado.
- Decision Log criado.
- Glossário criado.
- Template oficial da documentação criado.
- Processo oficial de transição criado.
- Processo oficial de bootstrap criado.
- Checklist oficial de transição criado.

---

# Estado do Roadmap

Fase Atual:

Engine Foundation

Status:

PAUSADO

Motivo:

Conclusão da Sprint de Consolidação.

---

# Próxima Sprint

Nome:

Gameplay Foundation

Primeiro módulo:

Monsters

---

# Módulos LOCKED

## Foundation

- Aggregate Root
- Value Objects
- Entities
- Character

## Character Domain

- Health
- Mana
- Experience
- Level
- Inventory
- Equipment
- Skills

## Progression

- Skill Progression
- Trainer
- Offline Training

## Item System

- Items
- Item Template
- Item Instance
- Item Factory
- Weapons
- Weapon Categories
- Affixes
- Imbuements

## Loot

- Loot
- Loot Tables
- Loot Entries

## Engine Foundation

- Vocations
- Resources
- Combat Architecture

---

# Módulos em Desenvolvimento

Nenhum.

---

# Próximo Módulo

Monsters

---

# Revisões Arquiteturais Pendentes

Nenhuma.

---

# Estado da Documentação

Consolidada.

A documentação oficial passa a ser suficiente para continuidade do projeto em novas conversas.

---

# Regras Permanentes

Durante o desenvolvimento:

- A documentação oficial representa a única fonte de verdade.
- Todo novo módulo deverá consultar o Roadmap.
- Todo novo módulo deverá consultar este documento.
- Nenhum módulo LOCKED poderá ser alterado sem revisão arquitetural.
- Toda decisão permanente deverá ser documentada.
- Toda Sprint deverá atualizar este documento.

---

# Próximo Objetivo

Retomar o desenvolvimento da Engine iniciando pelo módulo:

Monsters.