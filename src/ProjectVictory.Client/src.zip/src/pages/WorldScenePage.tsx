// src/ProjectVictory.Client/src/pages/WorldScenePage.tsx

import { useState } from "react";

import type { WorldState } from "../models/world";
import type { HuntResult } from "../models/hunt";
import type { RewardResult } from "../models/reward";

import PlayerInterface from "../components/player/PlayerInterface";

import PlayerIdentityArea from "../components/player/PlayerIdentityArea";
import PlayerActionsArea from "../components/player/PlayerActionsArea";
import PlayerCombatArea from "../components/player/PlayerCombatArea";
import PlayerRewardArea from "../components/player/PlayerRewardArea";

import GameplayPresentation from "../components/gameplayPresentation/GameplayPresentation";

import PlayerArea from "../components/gameplayPresentation/PlayerArea";
import HuntArea from "../components/gameplayPresentation/HuntArea";
import CombatArea from "../components/gameplayPresentation/CombatArea";
import ResultArea from "../components/gameplayPresentation/ResultArea";
import RewardArea from "../components/gameplayPresentation/RewardArea";

import HuntPanel from "../components/gameplay/HuntPanel";
import CombatResultPanel from "../components/gameplay/CombatResultPanel";
import RewardPanel from "../components/gameplay/RewardPanel";

import {
    startHunt
}
from "../services/huntService";

import Container from "../components/ui/Container";
import Card from "../components/ui/Card";



interface Props
{
    world: WorldState;

    onCharacterProgressionUpdate:
        (
            experience: number,
            level: number
        ) => void;
}



export default function WorldScenePage(
    {
        world,
        onCharacterProgressionUpdate
    }: Props
)
{
    const [huntResult, setHuntResult] =
        useState<HuntResult | null>(null);



    async function handleStartHunt()
    {
        const result =
            await startHunt();


        setHuntResult(
            result
        );


        if (result.completed)
        {
            onCharacterProgressionUpdate(
                world.player.experience + result.experience,
                result.level
            );
        }
    }



    const reward: RewardResult | null =
        huntResult
            ?
            {
                experience:
                    huntResult.experience,

                gold:
                    huntResult.gold
            }
            :
            null;



    return (
        <PlayerInterface>

            <Container>

                <section
                    className="pv-background-layer"
                    style={{
                        minHeight:
                            "100vh"
                    }}
                >

                    <div
                        className="pv-background-content"
                    >

                        <GameplayPresentation>

                            <PlayerArea>

                                <Card>

                                    <PlayerIdentityArea
                                        player={
                                            world.player
                                        }
                                    />

                                </Card>

                            </PlayerArea>



                            <HuntArea>

                                <Card>

                                    <PlayerActionsArea>

                                        <HuntPanel
                                            onStart={
                                                handleStartHunt
                                            }
                                        />

                                    </PlayerActionsArea>

                                </Card>

                            </HuntArea>



                            <CombatArea>

                                <Card>

                                    <PlayerCombatArea>

                                        <CombatResultPanel
                                            result={
                                                null
                                            }
                                        />

                                    </PlayerCombatArea>

                                </Card>

                            </CombatArea>



                            <ResultArea>

                                <Card>

                                    <CombatResultPanel
                                        result={
                                            null
                                        }
                                    />

                                    {
                                        huntResult &&
                                        (
                                            <section>

                                                <h2>
                                                    Hunt Result
                                                </h2>


                                                <p>
                                                    Completed:
                                                    {" "}
                                                    {
                                                        huntResult.completed
                                                            ? "Yes"
                                                            : "No"
                                                    }
                                                </p>


                                                <p>
                                                    Level:
                                                    {" "}
                                                    {
                                                        huntResult.level
                                                    }
                                                </p>

                                            </section>
                                        )
                                    }

                                </Card>

                            </ResultArea>



                            <RewardArea>

                                <Card>

                                    <PlayerRewardArea>

                                        <RewardPanel
                                            reward={
                                                reward
                                            }
                                        />

                                    </PlayerRewardArea>

                                </Card>

                            </RewardArea>


                        </GameplayPresentation>

                    </div>

                </section>

            </Container>

        </PlayerInterface>
    );
}