interface Props {
    total?: number;
    received?: number;
}

export default function CharacterCombatHealingSummaryPanel({ total = 0, received = 0 }: Props) {
    return (
        <section>
            <p>Total Healing: {total}</p>
            <p>Received Healing: {received}</p>
        </section>
    );
}
