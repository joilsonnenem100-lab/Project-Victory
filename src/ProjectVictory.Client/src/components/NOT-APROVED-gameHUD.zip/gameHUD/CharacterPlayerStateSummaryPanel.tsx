interface Props {
    state?: string;
}

export default function CharacterPlayerStateSummaryPanel({ state = '-' }: Props) {
    return (
        <section>
            State: {state}
        </section>
    );
}
