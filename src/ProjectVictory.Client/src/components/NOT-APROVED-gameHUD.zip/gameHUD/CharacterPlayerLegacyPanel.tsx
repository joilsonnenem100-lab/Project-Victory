interface Props {
    legacy?: string;
}

export default function CharacterPlayerLegacyPanel({ legacy = '-' }: Props) {
    return (
        <section>
            Legacy: {legacy}
        </section>
    );
}
