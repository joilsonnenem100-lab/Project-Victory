interface Props {
    threat?: string;
}

export default function EnemyThreatPanel({ threat = '-' }: Props) {
    return (
        <section>
            Threat: {threat}
        </section>
    );
}
