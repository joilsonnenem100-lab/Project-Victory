interface Props {
    armor?: number;
}

export default function ArmorPanel({armor = 0}: Props) {
    return (
        <section>
            Armor: {armor}
        </section>
    );
}
