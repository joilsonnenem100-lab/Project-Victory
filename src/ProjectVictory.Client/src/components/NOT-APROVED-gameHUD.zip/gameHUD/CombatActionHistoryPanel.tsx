interface Props {
    history?: string[];
}

export default function CombatActionHistoryPanel({ history = [] }: Props) {
    return (
        <section>
            {history.map((item, index) => (
                <p key={index}>{item}</p>
            ))}
        </section>
    );
}
