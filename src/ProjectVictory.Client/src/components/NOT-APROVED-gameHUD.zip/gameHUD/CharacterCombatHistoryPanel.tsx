interface Props {
    battles?: string[];
}

export default function CharacterCombatHistoryPanel({ battles = [] }: Props) {
    return (
        <section>
            {battles.map((battle, index) => (
                <p key={index}>{battle}</p>
            ))}
        </section>
    );
}
