interface Props {
    status?: string;
}

export default function CombatSimulationStatus({ status = '-' }: Props) {
    return (
        <section>
            Combat Status: {status}
        </section>
    );
}
