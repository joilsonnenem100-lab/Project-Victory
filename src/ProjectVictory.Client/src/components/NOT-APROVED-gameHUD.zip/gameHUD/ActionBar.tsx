interface ActionBarProps
{
    actions?: string[];
}


export default function ActionBar(
{
    actions = []

}: ActionBarProps)
{
    const defaultActions =
    [
        "Attack",
        "",
        "",
        "",
        "",
        "",
        "",
        ""
    ];


    const actionSlots =
        actions.length > 0
            ? actions
            : defaultActions;


    return (
        <div
            style={{
                display: "flex",

                justifyContent:
                    "center",

                gap:
                    "8px",

                padding:
                    "10px",

                border:
                    "1px solid #444"
            }}
        >

            {
                actionSlots.map(
                    (action, index) =>
                    (
                        <div
                            key={index}

                            style={{
                                width:
                                    "50px",

                                height:
                                    "50px",

                                border:
                                    "1px solid #666",

                                display:
                                    "flex",

                                alignItems:
                                    "center",

                                justifyContent:
                                    "center",

                                background:
                                    "#222",

                                fontSize:
                                    "12px"
                            }}
                        >

                            {
                                action ||
                                index + 1
                            }

                        </div>
                    )
                )
            }

        </div>
    );
}