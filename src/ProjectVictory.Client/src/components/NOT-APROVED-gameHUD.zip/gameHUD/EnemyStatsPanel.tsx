interface Props {
    stats?: Record<string, number>;
}

export default function EnemyStatsPanel({ stats = {} }: Props) {
    return (
        <section>
            {Object.entries(stats).map(([key, value]) => (
                <p key={key}>{key}: {value}</p>
            ))}
        </section>
    );
}
