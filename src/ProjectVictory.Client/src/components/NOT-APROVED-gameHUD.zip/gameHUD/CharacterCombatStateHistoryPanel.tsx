interface Props {
    states?: string[];
}

export default function CharacterCombatStateHistoryPanel({ states = [] }: Props) {
    return (
        <section>
            {states.map((state, index) => (
                <p key={index}>{state}</p>
            ))}
        </section>
    );
}
