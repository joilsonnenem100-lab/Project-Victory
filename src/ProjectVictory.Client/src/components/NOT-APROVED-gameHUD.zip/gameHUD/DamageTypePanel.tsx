interface Props {
    type?: string;
}

export default function DamageTypePanel({type = '-'}: Props) {
    return (
        <section>
            Damage Type: {type}
        </section>
    );
}
