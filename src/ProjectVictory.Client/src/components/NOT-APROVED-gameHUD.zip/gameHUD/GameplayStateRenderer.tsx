import React from "react";

import HuntStatusPanel from "./HuntStatusPanel";
import CombatStatusPanel from "./CombatStatusPanel";
import ActivityRewardPanel from "./ActivityRewardPanel";


interface GameplayStateRendererProps
{
    state?:
        | "idle"
        | "hunting"
        | "combat"
        | "reward";


    enemyName?: string;

    enemyHealth?: number;

    enemyMaxHealth?: number;


    experience?: number;

    gold?: number;

    items?: string[];
}



export default function GameplayStateRenderer(
{
    state = "idle",

    enemyName,

    enemyHealth,

    enemyMaxHealth,

    experience,

    gold,

    items

}: GameplayStateRendererProps)
{
    return (
        <>

            {
                state === "hunting" &&

                (
                    <HuntStatusPanel

                        active={
                            true
                        }

                        encounterName={
                            enemyName
                        }

                    />
                )
            }



            {
                state === "combat" &&

                (
                    <CombatStatusPanel

                        active={
                            true
                        }

                        enemyName={
                            enemyName
                        }

                        enemyHealth={
                            enemyHealth
                        }

                        enemyMaxHealth={
                            enemyMaxHealth
                        }

                    />
                )
            }



            {
                state === "reward" &&

                (
                    <ActivityRewardPanel

                        visible={
                            true
                        }

                        experience={
                            experience
                        }

                        gold={
                            gold
                        }

                        items={
                            items
                        }

                    />
                )
            }



            {
                state === "idle" &&

                (
                    <p>
                        Waiting for activity.
                    </p>
                )
            }

        </>
    );
}