interface Props {
    children?: React.ReactNode;
}

export default function HUDCentralPanelContainer({ children }: Props)
{
    return (
        <main>
            {children}
        </main>
    );
}
