interface Props {
    name?: string;
    identity?: string;
}

export default function CharacterPlayerIdentityPanel({ name = '-', identity = '-' }: Props) {
    return (
        <section>
            <p>Name: {name}</p>
            <p>Identity: {identity}</p>
        </section>
    );
}
