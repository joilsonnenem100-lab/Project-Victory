interface Props {
    level?: number;
    experience?: number;
}

export default function CharacterProgressionPanel({ level = 1, experience = 0 }: Props) {
    return (
        <section>
            <p>Level: {level}</p>
            <p>Experience: {experience}</p>
        </section>
    );
}
