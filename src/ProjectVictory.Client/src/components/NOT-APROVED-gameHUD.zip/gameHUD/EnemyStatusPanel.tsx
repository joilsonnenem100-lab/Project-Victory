interface Props {
    statuses?: string[];
}

export default function EnemyStatusPanel({ statuses = [] }: Props) {
    return (
        <section>
            {statuses.map((status, index) => (
                <p key={index}>{status}</p>
            ))}
        </section>
    );
}
