interface Props {
    recipes?: string[];
}

export default function CraftingPanel({ recipes = [] }: Props) {
    return (
        <section>
            {recipes.map((recipe, index) => (
                <p key={index}>{recipe}</p>
            ))}
        </section>
    );
}
