interface Props {
    damage?: number;
    armor?: number;
    speed?: number;
}

export default function CharacterCombatStatsPanel({ damage = 0, armor = 0, speed = 0 }: Props) {
    return (
        <section>
            <p>Damage: {damage}</p>
            <p>Armor: {armor}</p>
            <p>Speed: {speed}</p>
        </section>
    );
}
