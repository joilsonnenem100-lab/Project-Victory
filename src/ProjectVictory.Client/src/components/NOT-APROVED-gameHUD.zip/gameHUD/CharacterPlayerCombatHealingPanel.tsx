interface Props {
    healing?: number;
}

export default function CharacterPlayerCombatHealingPanel({ healing = 0 }: Props) {
    return (
        <section>
            Healing: {healing}
        </section>
    );
}
