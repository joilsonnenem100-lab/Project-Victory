interface Props {
    alignment?: string;
}

export default function CharacterPlayerAlignmentPanel({ alignment = '-' }: Props) {
    return (
        <section>
            Alignment: {alignment}
        </section>
    );
}
