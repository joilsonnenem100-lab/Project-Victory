export type HUDGameState =
    | "Idle"
    | "Hunting"
    | "CombatSimulation"
    | "Reward";
