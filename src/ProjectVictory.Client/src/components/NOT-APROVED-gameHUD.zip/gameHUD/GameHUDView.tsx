import React from "react";

import GameHUD from "./GameHUD";
import GameplayStateRenderer from "./GameplayStateRenderer";
import GameplayActionController from "./GameplayActionController";


type GameplayState =
    | "idle"
    | "hunting"
    | "combat"
    | "reward";



interface GameHUDViewProps
{
    state?: GameplayState;


    character?:
    {
        name?: string;

        level?: number;

        experience?: number;
    };


    inventoryItems?: string[];

    equipmentSlots?: string[];


    enemyName?: string;

    enemyHealth?: number;

    enemyMaxHealth?: number;


    experience?: number;

    gold?: number;

    items?: string[];


    onStartHunt?: () => void;

    onAttack?: () => void;

    onCollectReward?: () => void;
}



export default function GameHUDView(
{
    state = "idle",

    character,

    inventoryItems,

    equipmentSlots,

    enemyName,

    enemyHealth,

    enemyMaxHealth,

    experience,

    gold,

    items,

    onStartHunt,

    onAttack,

    onCollectReward

}: GameHUDViewProps)
{
    return (
        <GameHUD

            character={
                character
            }

            inventoryItems={
                inventoryItems
            }

            equipmentSlots={
                equipmentSlots
            }

        >

            <GameplayStateRenderer

                state={
                    state
                }

                enemyName={
                    enemyName
                }

                enemyHealth={
                    enemyHealth
                }

                enemyMaxHealth={
                    enemyMaxHealth
                }

                experience={
                    experience
                }

                gold={
                    gold
                }

                items={
                    items
                }

            />


            <GameplayActionController

                state={
                    state
                }

                onStartHunt={
                    onStartHunt
                }

                onAttack={
                    onAttack
                }

                onCollectReward={
                    onCollectReward
                }

            />


        </GameHUD>
    );
}