interface Props {
    targetName?: string;
}

export default function HUDBattleTargetArea({ targetName = "-" }: Props)
{
    return (
        <section>
            <h3>Target</h3>
            <p>{targetName}</p>
        </section>
    );
}
