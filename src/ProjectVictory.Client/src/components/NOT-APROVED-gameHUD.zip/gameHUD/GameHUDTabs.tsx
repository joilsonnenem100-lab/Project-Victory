import React, { useState } from "react";


interface GameHUDTabsProps
{
    tabs?:
    {
        id: string;

        label: string;

        content: React.ReactNode;
    }[];
}



export default function GameHUDTabs(
{
    tabs = []

}: GameHUDTabsProps)
{
    const [activeTab, setActiveTab] =
        useState(
            tabs[0]?.id ?? ""
        );


    const currentTab =
        tabs.find(
            tab =>
                tab.id === activeTab
        );


    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "10px"
            }}
        >

            <div
                style={{
                    display:
                        "flex",

                    gap:
                        "8px",

                    marginBottom:
                        "10px"
                }}
            >

                {
                    tabs.map(
                        tab =>
                        (
                            <button
                                key={
                                    tab.id
                                }

                                onClick={() =>
                                {
                                    setActiveTab(
                                        tab.id
                                    );
                                }}
                            >

                                {
                                    tab.label
                                }

                            </button>
                        )
                    )
                }

            </div>



            <div>

                {
                    currentTab?.content
                }

            </div>


        </section>
    );
}