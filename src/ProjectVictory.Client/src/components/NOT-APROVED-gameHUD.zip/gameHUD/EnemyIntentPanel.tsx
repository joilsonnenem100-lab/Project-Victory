interface Props {
    intent?: string;
}

export default function EnemyIntentPanel({ intent = '-' }: Props) {
    return (
        <section>
            Intent: {intent}
        </section>
    );
}
