import React from "react";


interface GameHUDWindowBodyProps
{
    children?: React.ReactNode;
}



export default function GameHUDWindowBody(
{
    children

}: GameHUDWindowBodyProps)
{
    return (
        <div
            style={{
                padding:
                    "8px",

                minHeight:
                    "40px"
            }}
        >

            {children}

        </div>
    );
}