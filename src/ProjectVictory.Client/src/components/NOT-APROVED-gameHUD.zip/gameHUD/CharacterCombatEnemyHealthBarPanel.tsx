interface Props {
    current?: number;
    maximum?: number;
}

export default function CharacterCombatEnemyHealthBarPanel({ current = 0, maximum = 0 }: Props) {
    return (
        <section>
            HP: {current}/{maximum}
        </section>
    );
}
