interface Props {
    current?: number;
    maximum?: number;
}

export default function CharacterCombatEnemyManaPanel({ current = 0, maximum = 0 }: Props) {
    return (
        <section>
            Mana: {current}/{maximum}
        </section>
    );
}
