interface Props {
    current?: number;
    maximum?: number;
}

export default function EnemyHealthBarPanel({ current = 0, maximum = 0 }: Props) {
    return (
        <section>
            Health: {current}/{maximum}
        </section>
    );
}
