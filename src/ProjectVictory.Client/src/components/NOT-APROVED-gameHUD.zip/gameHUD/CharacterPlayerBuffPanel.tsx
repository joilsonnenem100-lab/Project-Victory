interface Props {
    buffs?: string[];
}

export default function CharacterPlayerBuffPanel({ buffs = [] }: Props) {
    return (
        <section>
            {buffs.map((buff, index) => (
                <p key={index}>{buff}</p>
            ))}
        </section>
    );
}
