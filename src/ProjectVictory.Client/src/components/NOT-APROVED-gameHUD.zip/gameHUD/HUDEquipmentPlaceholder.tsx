export default function HUDEquipmentPlaceholder()
{
    return (
        <section>
            <h3>Equipment</h3>
            <p>Reserved Area</p>
        </section>
    );
}
