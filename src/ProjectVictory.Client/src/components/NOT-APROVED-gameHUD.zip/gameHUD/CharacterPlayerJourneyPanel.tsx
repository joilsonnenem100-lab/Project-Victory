interface Props {
    journey?: string;
}

export default function CharacterPlayerJourneyPanel({ journey = '-' }: Props) {
    return (
        <section>
            Journey: {journey}
        </section>
    );
}
