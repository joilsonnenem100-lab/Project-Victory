interface Props {
    seconds?: number;
}

export default function HUDActivityTimerArea(
{
    seconds = 0

}: Props)
{
    return (
        <section>
            <h3>Activity Timer</h3>
            <p>{seconds}s</p>
        </section>
    );
}
