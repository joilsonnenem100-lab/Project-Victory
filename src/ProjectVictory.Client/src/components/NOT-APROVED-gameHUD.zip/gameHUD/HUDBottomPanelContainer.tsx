interface Props {
    children?: React.ReactNode;
}

export default function HUDBottomPanelContainer({ children }: Props)
{
    return (
        <footer>
            {children}
        </footer>
    );
}
