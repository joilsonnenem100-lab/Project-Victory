interface Props {
    resources?: Record<string, number>;
}

export default function CharacterPlayerCombatResourcePanel({ resources = {} }: Props) {
    return (
        <section>
            {Object.entries(resources).map(([key, value]) => (
                <p key={key}>{key}: {value}</p>
            ))}
        </section>
    );
}
