interface Props {
    current?: number;
    total?: number;
}

export default function CharacterPlayerCombatWavePanel({ current = 0, total = 0 }: Props) {
    return (
        <section>
            Wave: {current}/{total}
        </section>
    );
}
