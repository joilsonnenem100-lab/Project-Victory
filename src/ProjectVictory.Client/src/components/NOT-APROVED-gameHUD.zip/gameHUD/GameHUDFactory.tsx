import React from "react";

import GameHUDView from "./GameHUDView";


interface GameHUDFactoryProps
{
    children?: React.ReactNode;


    character?:
    {
        name?: string;

        level?: number;

        experience?: number;
    };


    inventoryItems?: string[];

    equipmentSlots?: string[];


    state?:
        | "idle"
        | "hunting"
        | "combat"
        | "reward";
}



export default function GameHUDFactory(
{
    children,

    character,

    inventoryItems,

    equipmentSlots,

    state = "idle"

}: GameHUDFactoryProps)
{
    return (
        <GameHUDView

            state={
                state
            }

            character={
                character
            }

            inventoryItems={
                inventoryItems
            }

            equipmentSlots={
                equipmentSlots
            }

        >

            {children}

        </GameHUDView>
    );
}