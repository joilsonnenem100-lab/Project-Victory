interface Props {
    gold?: number;
}

export default function CurrencyPanel({ gold = 0 }: Props) {
    return (
        <section>
            Gold: {gold}
        </section>
    );
}
