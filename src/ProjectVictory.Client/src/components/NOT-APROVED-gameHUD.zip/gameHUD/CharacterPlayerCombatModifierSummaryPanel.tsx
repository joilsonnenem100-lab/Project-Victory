interface Props {
    modifiers?: Record<string, number>;
}

export default function CharacterPlayerCombatModifierSummaryPanel({ modifiers = {} }: Props) {
    return (
        <section>
            {Object.entries(modifiers).map(([key, value]) => (
                <p key={key}>{key}: {value}</p>
            ))}
        </section>
    );
}
