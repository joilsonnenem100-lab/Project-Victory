interface Props {
    children?: React.ReactNode;
}

export default function HUDContentArea({ children }: Props)
{
    return (
        <section>
            {children}
        </section>
    );
}
