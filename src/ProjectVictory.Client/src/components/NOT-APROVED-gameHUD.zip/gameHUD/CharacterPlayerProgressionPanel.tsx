interface Props {
    progress?: string;
}

export default function CharacterPlayerProgressionPanel({ progress = '-' }: Props) {
    return (
        <section>
            Progression: {progress}
        </section>
    );
}
