interface Props {
    message?: string;
}

export default function HUDCombatLogArea({ message = "" }: Props)
{
    return (
        <section>
            <h3>Combat Log</h3>
            <p>{message}</p>
        </section>
    );
}
