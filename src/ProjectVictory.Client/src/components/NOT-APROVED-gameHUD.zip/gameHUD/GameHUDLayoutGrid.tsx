import React from "react";


interface GameHUDLayoutGridProps
{
    header?: React.ReactNode;

    center?: React.ReactNode;

    right?: React.ReactNode;

    footer?: React.ReactNode;
}



export default function GameHUDLayoutGrid(
{
    header,

    center,

    right,

    footer

}: GameHUDLayoutGridProps)
{
    return (
        <main
            style={{
                display:
                    "grid",

                gridTemplateRows:
                    "90px 1fr 180px",

                gridTemplateColumns:
                    "1fr 320px",

                height:
                    "100vh",

                width:
                    "100vw"
            }}
        >

            <header
                style={{
                    gridColumn:
                        "1 / 3"
                }}
            >

                {header}

            </header>



            <section>

                {center}

            </section>



            <aside>

                {right}

            </aside>



            <footer
                style={{
                    gridColumn:
                        "1 / 3"
                }}
            >

                {footer}

            </footer>


        </main>
    );
}