interface Props {
    message?: string;
}

export default function EquipmentUpgradeResultPanel({ message = '-' }: Props) {
    return (
        <section>
            {message}
        </section>
    );
}
