interface Props {
    ability?: string;
    description?: string;
}

export default function CharacterCombatAbilityPreviewPanel({ ability = '-', description = '' }: Props) {
    return (
        <section>
            <h3>{ability}</h3>
            <p>{description}</p>
        </section>
    );
}
