interface Props {
    active?: boolean;
}

export default function CombatModeIndicator({ active = false }: Props) {
    return (
        <section>
            Mode: {active ? "Combat" : "Normal"}
        </section>
    );
}
