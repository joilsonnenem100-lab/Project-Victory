interface Props {
    entries?: string[];
}

export default function CharacterPlayerCombatLogPanel({ entries = [] }: Props) {
    return (
        <section>
            {entries.map((entry, index) => (
                <p key={index}>{entry}</p>
            ))}
        </section>
    );
}
