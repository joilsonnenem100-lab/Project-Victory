interface CharacterStatusPanelProps
{
    name?: string;

    level?: number;

    experience?: number;
}


export default function CharacterStatusPanel(
{
    name = "-",

    level = 0,

    experience = 0

}: CharacterStatusPanelProps)
{
    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "10px",

                width:
                    "100%"
            }}
        >

            <h3>
                Character
            </h3>


            <p>
                Name:
                {" "}
                {name}
            </p>


            <p>
                Level:
                {" "}
                {level}
            </p>


            <p>
                Experience:
                {" "}
                {experience}
            </p>


        </section>
    );
}