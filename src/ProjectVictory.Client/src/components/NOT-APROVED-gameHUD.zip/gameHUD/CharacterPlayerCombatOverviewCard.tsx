interface Props {
    health?: number;
    status?: string;
    action?: string;
}

export default function CharacterPlayerCombatOverviewCard({ health = 0, status = '-', action = '-' }: Props) {
    return (
        <section>
            <p>Health: {health}</p>
            <p>Status: {status}</p>
            <p>Action: {action}</p>
        </section>
    );
}
