interface Props {
    strategy?: string;
}

export default function CharacterCombatEnemyStrategyPanel({ strategy = '-' }: Props) {
    return (
        <section>
            Strategy: {strategy}
        </section>
    );
}
