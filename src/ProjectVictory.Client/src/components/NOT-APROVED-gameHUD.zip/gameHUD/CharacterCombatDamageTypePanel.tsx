interface Props {
    type?: string;
}

export default function CharacterCombatDamageTypePanel({ type = '-' }: Props) {
    return (
        <section>
            Damage Type: {type}
        </section>
    );
}
