interface Props {
    physical?: number;
    magical?: number;
}

export default function CombatResistanceBreakdownPanel({ physical = 0, magical = 0 }: Props) {
    return (
        <section>
            <p>Physical: {physical}</p>
            <p>Magical: {magical}</p>
        </section>
    );
}
