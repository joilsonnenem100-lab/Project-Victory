interface Props {
    enemy?: string;
    encounters?: number;
}

export default function CharacterCombatEncounterPanel({ enemy = '-', encounters = 0 }: Props) {
    return (
        <section>
            <p>Enemy: {enemy}</p>
            <p>Encounters: {encounters}</p>
        </section>
    );
}
