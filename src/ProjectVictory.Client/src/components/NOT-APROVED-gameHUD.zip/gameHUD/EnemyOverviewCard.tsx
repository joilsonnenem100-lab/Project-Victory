interface Props {
    name?: string;
    health?: number;
    level?: number;
}

export default function EnemyOverviewCard({ name = '-', health = 0, level = 0 }: Props) {
    return (
        <section>
            <p>{name}</p>
            <p>Health: {health}</p>
            <p>Level: {level}</p>
        </section>
    );
}
