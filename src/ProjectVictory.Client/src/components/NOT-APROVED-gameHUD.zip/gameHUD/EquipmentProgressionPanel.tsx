interface Props {
    children?: React.ReactNode;
}

export default function EquipmentProgressionPanel({ children }: Props) {
    return (
        <section>
            {children}
        </section>
    );
}
