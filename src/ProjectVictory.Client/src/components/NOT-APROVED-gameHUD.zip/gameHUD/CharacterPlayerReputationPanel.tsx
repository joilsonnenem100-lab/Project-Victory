interface Props {
    reputation?: Record<string, number>;
}

export default function CharacterPlayerReputationPanel({ reputation = {} }: Props) {
    return (
        <section>
            {Object.entries(reputation).map(([key, value]) => (
                <p key={key}>{key}: {value}</p>
            ))}
        </section>
    );
}
