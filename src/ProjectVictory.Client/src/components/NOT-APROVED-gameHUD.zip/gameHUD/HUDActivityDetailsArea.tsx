interface Props {
    details?: string;
}

export default function HUDActivityDetailsArea(
{
    details = ""

}: Props)
{
    return (
        <section>
            <h3>Details</h3>
            <p>{details}</p>
        </section>
    );
}
