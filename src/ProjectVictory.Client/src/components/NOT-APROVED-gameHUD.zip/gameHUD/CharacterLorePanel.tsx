interface Props {
    lore?: string;
}

export default function CharacterLorePanel({ lore = '' }: Props) {
    return (
        <section>
            {lore}
        </section>
    );
}
