interface Props {
    slots?: string[];
}

export default function CharacterLoadoutPanel({ slots = [] }: Props) {
    return (
        <section>
            {slots.map((slot, index) => (
                <p key={index}>{slot}</p>
            ))}
        </section>
    );
}
