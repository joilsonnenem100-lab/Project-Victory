import React from "react";


interface GameHUDWindowFooterProps
{
    children?: React.ReactNode;
}



export default function GameHUDWindowFooter(
{
    children

}: GameHUDWindowFooterProps)
{
    return (
        <footer
            style={{
                borderTop:
                    "1px solid #444",

                paddingTop:
                    "8px",

                marginTop:
                    "8px",

                display:
                    "flex",

                justifyContent:
                    "flex-end"
            }}
        >

            {children}

        </footer>
    );
}