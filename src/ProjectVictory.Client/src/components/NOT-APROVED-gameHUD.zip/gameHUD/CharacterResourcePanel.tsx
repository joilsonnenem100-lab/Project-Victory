interface Props {
    health?: number;
    mana?: number;
    stamina?: number;
}

export default function CharacterResourcePanel({ health = 0, mana = 0, stamina = 0 }: Props) {
    return (
        <section>
            <p>HP: {health}</p>
            <p>MP: {mana}</p>
            <p>Stamina: {stamina}</p>
        </section>
    );
}
