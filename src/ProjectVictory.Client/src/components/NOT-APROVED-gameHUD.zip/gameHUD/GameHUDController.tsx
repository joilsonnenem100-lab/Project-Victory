import React, { useState } from "react";


type GameplayState =
    | "idle"
    | "hunting"
    | "combat"
    | "reward";



interface GameHUDControllerProps
{
    children?:
        (
            state: GameplayState,

            actions:
            {
                startHunt: () => void;

                startCombat: () => void;

                showReward: () => void;

                reset: () => void;
            }

        ) => React.ReactNode;
}



export default function GameHUDController(
{
    children

}: GameHUDControllerProps)
{
    const [state, setState] =
        useState<GameplayState>("idle");



    const actions =
    {
        startHunt()
        {
            setState("hunting");
        },


        startCombat()
        {
            setState("combat");
        },


        showReward()
        {
            setState("reward");
        },


        reset()
        {
            setState("idle");
        }
    };



    return (
        <>
            {
                children?.(
                    state,

                    actions
                )
            }
        </>
    );
}