interface EncounterActionPanelProps
{
    target?: string;

    onAttack?: () => void;

    onRun?: () => void;
}



export default function EncounterActionPanel(
{
    target = "-",

    onAttack,

    onRun

}: EncounterActionPanelProps)
{
    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "10px",

                width:
                    "100%"
            }}
        >

            <h3>
                Encounter Actions
            </h3>


            <p>
                Target:
                {" "}
                {target}
            </p>


            <button
                onClick={
                    onAttack
                }
            >
                Attack
            </button>


            <button
                onClick={
                    onRun
                }
                style={{
                    marginLeft:
                        "8px"
                }}
            >
                Run
            </button>


        </section>
    );
}