interface Props {
    message?: string;
}

export default function CharacterPlayerCombatMessagePanel({ message = '-' }: Props) {
    return (
        <section>
            {message}
        </section>
    );
}
