interface Props {
    goals?: string[];
}

export default function CharacterGoalPanel({ goals = [] }: Props) {
    return (
        <section>
            {goals.map((goal, index) => (
                <p key={index}>{goal}</p>
            ))}
        </section>
    );
}
