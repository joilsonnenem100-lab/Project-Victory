interface Props {
    entries?: string[];
}

export default function CharacterCombatHistorySummaryPanel({ entries = [] }: Props) {
    return (
        <section>
            {entries.map((entry, index) => (
                <p key={index}>{entry}</p>
            ))}
        </section>
    );
}
