export interface EquipmentStateModel {
    slot?: string;
    item?: string;
    power?: number;
}
