import ActionBar from "./ActionBar";
import GameLogPanel from "./GameLogPanel";
import InformationPanel from "./InformationPanel";


interface GameFooterProps
{
    actions?: string[];

    messages?: string[];

    information?: React.ReactNode;
}



export default function GameFooter(
{
    actions,

    messages,

    information

}: GameFooterProps)
{
    return (
        <footer
            style={{
                display:
                    "flex",

                flexDirection:
                    "column",

                gap:
                    "10px",

                border:
                    "1px solid #444",

                padding:
                    "10px"
            }}
        >

            <div
                style={{
                    display:
                        "grid",

                    gridTemplateColumns:
                        "1fr 1fr",

                    gap:
                        "10px"
                }}
            >

                <GameLogPanel

                    messages={
                        messages
                    }

                />


                <InformationPanel

                    content={
                        information
                    }

                />

            </div>



            <ActionBar

                actions={
                    actions
                }

            />

        </footer>
    );
}