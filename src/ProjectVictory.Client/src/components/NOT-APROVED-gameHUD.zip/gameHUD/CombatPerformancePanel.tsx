interface Props {
    performance?: number;
}

export default function CombatPerformancePanel({ performance = 0 }: Props) {
    return (
        <section>
            Performance: {performance}
        </section>
    );
}
