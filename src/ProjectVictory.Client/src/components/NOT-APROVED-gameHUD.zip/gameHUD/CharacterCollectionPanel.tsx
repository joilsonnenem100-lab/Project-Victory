interface Props {
    collections?: string[];
}

export default function CharacterCollectionPanel({ collections = [] }: Props) {
    return (
        <section>
            {collections.map((collection, index) => (
                <p key={index}>{collection}</p>
            ))}
        </section>
    );
}
