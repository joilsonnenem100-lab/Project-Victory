interface Props {
    skill?: string;
    description?: string;
}

export default function CharacterPlayerSkillPreviewPanel({ skill = '-', description = '' }: Props) {
    return (
        <section>
            <h3>{skill}</h3>
            <p>{description}</p>
        </section>
    );
}
