interface Props {
    victory?: boolean;
}

export default function CharacterPlayerCombatVictoryPanel({ victory = false }: Props) {
    return (
        <section>
            {victory ? "Victory" : "In Progress"}
        </section>
    );
}
