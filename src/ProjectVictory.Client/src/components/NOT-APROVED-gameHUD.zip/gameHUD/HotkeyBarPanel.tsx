interface Props {
    actions?: string[];
}

export default function HotkeyBarPanel({ actions = [] }: Props) {
    return (
        <section>
            <h3>Hotkeys</h3>
            {actions.map((action, index) => (
                <button key={index}>{action}</button>
            ))}
        </section>
    );
}
