interface Props {
    children?: React.ReactNode;
}

export default function HUDFooterArea({ children }: Props)
{
    return (
        <footer>
            {children}
        </footer>
    );
}
