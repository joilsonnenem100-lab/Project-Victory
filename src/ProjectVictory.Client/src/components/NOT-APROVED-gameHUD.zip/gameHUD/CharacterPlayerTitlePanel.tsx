interface Props {
    title?: string;
}

export default function CharacterPlayerTitlePanel({ title = '-' }: Props) {
    return (
        <section>
            Title: {title}
        </section>
    );
}
