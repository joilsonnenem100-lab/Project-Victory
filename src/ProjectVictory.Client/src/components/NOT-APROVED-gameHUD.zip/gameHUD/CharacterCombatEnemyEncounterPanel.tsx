interface Props {
    encounter?: string;
}

export default function CharacterCombatEnemyEncounterPanel({ encounter = '-' }: Props) {
    return (
        <section>
            Encounter: {encounter}
        </section>
    );
}
