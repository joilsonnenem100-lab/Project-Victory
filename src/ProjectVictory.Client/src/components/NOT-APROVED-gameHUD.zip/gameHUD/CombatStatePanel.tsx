interface Props {
    state?: string;
}

export default function CombatStatePanel({ state = '-' }: Props) {
    return (
        <section>
            Combat State: {state}
        </section>
    );
}
