import GameHUDButton from "./GameHUDButton";


interface GameHUDButtonGroupProps
{
    buttons?:
    {
        label: string;

        onClick?: () => void;

        disabled?: boolean;
    }[];
}



export default function GameHUDButtonGroup(
{
    buttons = []

}: GameHUDButtonGroupProps)
{
    return (
        <section
            style={{
                display:
                    "flex",

                gap:
                    "8px",

                padding:
                    "8px",

                border:
                    "1px solid #444"
            }}
        >

            {
                buttons.map(
                    (button, index) =>
                    (
                        <GameHUDButton

                            key={
                                index
                            }

                            label={
                                button.label
                            }

                            onClick={
                                button.onClick
                            }

                            disabled={
                                button.disabled
                            }

                        />
                    )
                )
            }


        </section>
    );
}