interface Props {
    name?: string;
    level?: number;
    result?: string;
}

export default function CharacterPlayerCombatSummaryOverviewPanel({ name = '-', level = 0, result = '-' }: Props) {
    return (
        <section>
            <p>{name}</p>
            <p>Level: {level}</p>
            <p>Result: {result}</p>
        </section>
    );
}
