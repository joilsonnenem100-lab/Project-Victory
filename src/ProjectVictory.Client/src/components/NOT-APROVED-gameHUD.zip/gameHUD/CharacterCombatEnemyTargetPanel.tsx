interface Props {
    target?: string;
}

export default function CharacterCombatEnemyTargetPanel({ target = '-' }: Props) {
    return (
        <section>
            Target: {target}
        </section>
    );
}
