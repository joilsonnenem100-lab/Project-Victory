interface Props {
    resistances?: Record<string, number>;
}

export default function CharacterPlayerResistancePanel({ resistances = {} }: Props) {
    return (
        <section>
            {Object.entries(resistances).map(([key, value]) => (
                <p key={key}>{key}: {value}</p>
            ))}
        </section>
    );
}
