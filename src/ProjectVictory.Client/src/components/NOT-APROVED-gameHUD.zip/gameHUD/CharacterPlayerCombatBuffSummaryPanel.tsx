interface Props {
    buffs?: string[];
}

export default function CharacterPlayerCombatBuffSummaryPanel({ buffs = [] }: Props) {
    return (
        <section>
            {buffs.map((buff, index) => (
                <p key={index}>{buff}</p>
            ))}
        </section>
    );
}
