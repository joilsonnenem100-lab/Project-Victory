interface Props {
    rank?: number;
}

export default function CharacterPlayerCombatRankingPanel({ rank = 0 }: Props) {
    return (
        <section>
            Rank: {rank}
        </section>
    );
}
