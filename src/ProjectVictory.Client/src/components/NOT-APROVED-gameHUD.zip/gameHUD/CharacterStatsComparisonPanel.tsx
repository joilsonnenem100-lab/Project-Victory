interface Props {
    current?: Record<string, number>;
    preview?: Record<string, number>;
}

export default function CharacterStatsComparisonPanel({ current = {}, preview = {} }: Props) {
    return (
        <section>
            <h3>Current</h3>
            {Object.entries(current).map(([key, value]) => (
                <p key={key}>{key}: {value}</p>
            ))}
            <h3>Preview</h3>
            {Object.entries(preview).map(([key, value]) => (
                <p key={key}>{key}: {value}</p>
            ))}
        </section>
    );
}
