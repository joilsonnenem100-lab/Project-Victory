interface Props {
    action?: string;
    confirmed?: boolean;
}

export default function CombatActionConfirmationPanel({ action = '-', confirmed = false }: Props) {
    return (
        <section>
            <p>Action: {action}</p>
            <p>{confirmed ? "Confirmed" : "Pending"}</p>
        </section>
    );
}
