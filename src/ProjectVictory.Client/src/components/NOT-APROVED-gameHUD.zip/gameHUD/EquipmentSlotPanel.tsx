interface Props {
    slots?: string[];
}

export default function EquipmentSlotPanel({ slots = [] }: Props) {
    return (
        <section>
            <h3>Equipment</h3>
            {slots.map((slot, index) => (
                <div key={index}>{slot}</div>
            ))}
        </section>
    );
}
