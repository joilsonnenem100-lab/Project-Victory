interface Props {
    result?: string;
}

export default function CombatResultPanel({ result = '-' }: Props) {
    return (
        <section>
            Result: {result}
        </section>
    );
}
