interface Props {
    threat?: number;
}

export default function CharacterCombatEnemyThreatPanel({ threat = 0 }: Props) {
    return (
        <section>
            Threat: {threat}
        </section>
    );
}
