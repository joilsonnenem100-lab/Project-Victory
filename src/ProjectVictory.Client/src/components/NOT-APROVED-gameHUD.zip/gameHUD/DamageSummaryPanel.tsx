interface Props {
    damage?: number;
    healing?: number;
}

export default function DamageSummaryPanel({ damage = 0, healing = 0 }: Props) {
    return (
        <section>
            <p>Damage: {damage}</p>
            <p>Healing: {healing}</p>
        </section>
    );
}
