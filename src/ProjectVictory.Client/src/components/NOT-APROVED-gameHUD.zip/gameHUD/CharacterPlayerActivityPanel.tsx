interface Props {
    activity?: string;
}

export default function CharacterPlayerActivityPanel({ activity = '-' }: Props) {
    return (
        <section>
            Activity: {activity}
        </section>
    );
}
