interface Props {
    target?: string;
}

export default function CharacterTargetPanel({ target = '-' }: Props) {
    return (
        <section>
            Target: {target}
        </section>
    );
}
