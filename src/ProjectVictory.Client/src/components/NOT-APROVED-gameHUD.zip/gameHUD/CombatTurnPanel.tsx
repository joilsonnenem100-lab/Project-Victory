interface Props {
    turn?: number;
}

export default function CombatTurnPanel({ turn = 0 }: Props) {
    return (
        <section>
            Turn: {turn}
        </section>
    );
}
