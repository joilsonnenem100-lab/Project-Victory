interface Props {
    healing?: number;
}

export default function CharacterCombatHealingPanel({ healing = 0 }: Props) {
    return (
        <section>
            Healing: {healing}
        </section>
    );
}
