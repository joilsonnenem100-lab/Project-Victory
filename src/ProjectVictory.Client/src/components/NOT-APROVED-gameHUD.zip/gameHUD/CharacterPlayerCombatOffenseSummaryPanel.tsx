interface Props {
    damage?: number;
    attackPower?: number;
}

export default function CharacterPlayerCombatOffenseSummaryPanel({ damage = 0, attackPower = 0 }: Props) {
    return (
        <section>
            <p>Damage: {damage}</p>
            <p>Attack Power: {attackPower}</p>
        </section>
    );
}
