import React from "react";


interface GameHUDWindowProps
{
    title?: string;

    children?: React.ReactNode;

    visible?: boolean;
}



export default function GameHUDWindow(
{
    title = "",

    children,

    visible = true

}: GameHUDWindowProps)
{
    if (!visible)
    {
        return null;
    }


    return (
        <section
            style={{
                border:
                    "1px solid #444",

                background:
                    "#111",

                padding:
                    "12px",

                width:
                    "100%"
            }}
        >

            {
                title &&

                <h3>
                    {title}
                </h3>
            }



            <div>
                {children}
            </div>


        </section>
    );
}