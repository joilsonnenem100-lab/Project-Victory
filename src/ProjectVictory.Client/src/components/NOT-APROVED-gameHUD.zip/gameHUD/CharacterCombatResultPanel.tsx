interface Props {
    result?: string;
}

export default function CharacterCombatResultPanel({ result = '-' }: Props) {
    return (
        <section>
            Result: {result}
        </section>
    );
}
