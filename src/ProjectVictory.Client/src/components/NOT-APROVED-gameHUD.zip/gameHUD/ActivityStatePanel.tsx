interface ActivityStatePanelProps
{
    state?:
        | "idle"
        | "hunting"
        | "combat"
        | "reward";


    message?: string;
}



export default function ActivityStatePanel(
{
    state = "idle",

    message = ""

}: ActivityStatePanelProps)
{
    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "10px",

                width:
                    "100%"
            }}
        >

            <h3>
                Activity State
            </h3>


            <p>
                State:
                {" "}
                {state}
            </p>


            {
                message &&

                <p>
                    {message}
                </p>
            }


        </section>
    );
}