interface Props {
    experience?: number;
}

export default function CharacterPlayerCombatExperiencePanel({ experience = 0 }: Props) {
    return (
        <section>
            Combat Experience: {experience}
        </section>
    );
}
