interface Props {
    experience?: number;
    nextLevel?: number;
}

export default function CharacterProgressSummaryPanel({ experience = 0, nextLevel = 0 }: Props) {
    return (
        <section>
            <p>Experience: {experience}</p>
            <p>Next Level: {nextLevel}</p>
        </section>
    );
}
