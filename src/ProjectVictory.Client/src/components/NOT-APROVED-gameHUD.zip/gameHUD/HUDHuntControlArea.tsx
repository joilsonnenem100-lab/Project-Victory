interface Props {
    onStartHunt?: () => void;
}

export default function HUDHuntControlArea(
{
    onStartHunt

}: Props)
{
    return (
        <section>
            <h3>Hunt Control</h3>

            <button onClick={onStartHunt}>
                Start Hunt
            </button>
        </section>
    );
}
