interface Props {
    lines?: string[];
}

export default function DialoguePanel({ lines = [] }: Props) {
    return (
        <section>
            {lines.map((line, index) => (
                <p key={index}>{line}</p>
            ))}
        </section>
    );
}
