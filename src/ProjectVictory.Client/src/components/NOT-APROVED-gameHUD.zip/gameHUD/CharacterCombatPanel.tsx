interface Props {
    attack?: number;
    defense?: number;
}

export default function CharacterCombatPanel({ attack = 0, defense = 0 }: Props) {
    return (
        <section>
            <p>Attack: {attack}</p>
            <p>Defense: {defense}</p>
        </section>
    );
}
