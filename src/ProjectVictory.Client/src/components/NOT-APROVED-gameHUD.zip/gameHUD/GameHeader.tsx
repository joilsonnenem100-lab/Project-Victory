import TopStatusBar from "./TopStatusBar";


interface GameHeaderProps
{
    health?: number;

    maxHealth?: number;

    mana?: number;

    maxMana?: number;

    experience?: number;

    experiencePercent?: number;
}



export default function GameHeader(
{
    health,

    maxHealth,

    mana,

    maxMana,

    experience,

    experiencePercent

}: GameHeaderProps)
{
    return (
        <header
            style={{
                border:
                    "1px solid #444",

                width:
                    "100%"
            }}
        >

            <TopStatusBar

                health={
                    health
                }

                maxHealth={
                    maxHealth
                }

                mana={
                    mana
                }

                maxMana={
                    maxMana
                }

                experience={
                    experience
                }

                experiencePercent={
                    experiencePercent
                }

            />

        </header>
    );
}