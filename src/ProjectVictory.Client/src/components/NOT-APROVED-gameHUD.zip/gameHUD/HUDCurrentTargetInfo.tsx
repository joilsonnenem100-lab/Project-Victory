interface Props {
    target?: string;
}

export default function HUDCurrentTargetInfo(
{
    target = "-"

}: Props)
{
    return (
        <section>
            <h3>Current Target</h3>
            <p>{target}</p>
        </section>
    );
}
