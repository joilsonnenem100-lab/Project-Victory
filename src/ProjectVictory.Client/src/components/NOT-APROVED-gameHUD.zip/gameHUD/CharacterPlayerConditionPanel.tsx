interface Props {
    condition?: string;
}

export default function CharacterPlayerConditionPanel({ condition = '-' }: Props) {
    return (
        <section>
            Condition: {condition}
        </section>
    );
}
