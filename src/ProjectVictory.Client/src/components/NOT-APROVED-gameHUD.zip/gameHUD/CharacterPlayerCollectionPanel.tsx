interface Props {
    collections?: string[];
}

export default function CharacterPlayerCollectionPanel({ collections = [] }: Props) {
    return (
        <section>
            {collections.map((collection, index) => (
                <p key={index}>{collection}</p>
            ))}
        </section>
    );
}
