interface Props {
    impact?: string;
}

export default function CharacterPlayerWorldImpactPanel({ impact = '-' }: Props) {
    return (
        <section>
            World Impact: {impact}
        </section>
    );
}
