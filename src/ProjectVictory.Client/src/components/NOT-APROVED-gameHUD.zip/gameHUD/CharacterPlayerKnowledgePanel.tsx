interface Props {
    knowledge?: string[];
}

export default function CharacterPlayerKnowledgePanel({ knowledge = [] }: Props) {
    return (
        <section>
            {knowledge.map((item, index) => (
                <p key={index}>{item}</p>
            ))}
        </section>
    );
}
