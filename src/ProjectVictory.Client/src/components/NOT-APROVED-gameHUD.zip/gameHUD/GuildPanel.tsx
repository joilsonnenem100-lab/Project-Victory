interface Props {
    guild?: string;
}

export default function GuildPanel({ guild = '-' }: Props) {
    return (
        <section>
            Guild: {guild}
        </section>
    );
}
