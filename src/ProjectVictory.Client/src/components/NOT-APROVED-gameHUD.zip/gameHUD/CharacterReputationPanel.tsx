interface Props {
    reputation?: number;
}

export default function CharacterReputationPanel({ reputation = 0 }: Props) {
    return (
        <section>
            Reputation: {reputation}
        </section>
    );
}
