interface Props {
    nodes?: string[];
}

export default function CharacterSkillTreePanel({ nodes = [] }: Props) {
    return (
        <section>
            {nodes.map((node, index) => (
                <p key={index}>{node}</p>
            ))}
        </section>
    );
}
