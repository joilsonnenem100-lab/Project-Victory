interface Props {
    honor?: number;
}

export default function CharacterPlayerHonorPanel({ honor = 0 }: Props) {
    return (
        <section>
            Honor: {honor}
        </section>
    );
}
