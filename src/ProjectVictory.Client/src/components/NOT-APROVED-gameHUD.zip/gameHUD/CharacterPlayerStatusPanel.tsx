interface Props {
    status?: string;
}

export default function CharacterPlayerStatusPanel({ status = '-' }: Props) {
    return (
        <section>
            Player Status: {status}
        </section>
    );
}
