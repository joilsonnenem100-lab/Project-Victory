interface Props {
    abilities?: string[];
}

export default function CombatAbilityPanel({ abilities = [] }: Props) {
    return (
        <section>
            <h3>Abilities</h3>
            {abilities.map((ability, index) => (
                <button key={index}>{ability}</button>
            ))}
        </section>
    );
}
