interface GameLogPanelProps
{
    messages?: string[];
}


export default function GameLogPanel(
{
    messages = []

}: GameLogPanelProps)
{
    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "10px",

                height:
                    "100%",

                overflowY:
                    "auto"
            }}
        >

            <h3>
                Game Log
            </h3>


            {
                messages.length === 0

                ?

                (
                    <p>
                        No events.
                    </p>
                )

                :

                (
                    messages.map(
                        (message, index) =>
                        (
                            <p
                                key={index}
                            >
                                {message}
                            </p>
                        )
                    )
                )
            }


        </section>
    );
}