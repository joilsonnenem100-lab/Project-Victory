interface Props {
    energy?: number;
}

export default function CharacterCombatEnemyEnergyPanel({ energy = 0 }: Props) {
    return (
        <section>
            Energy: {energy}
        </section>
    );
}
