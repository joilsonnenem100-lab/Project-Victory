interface Props {
    title?: string;
}

export default function HUDHeaderArea(
{
    title = "Project Victory"

}: Props)
{
    return (
        <header>
            <h2>{title}</h2>
        </header>
    );
}
