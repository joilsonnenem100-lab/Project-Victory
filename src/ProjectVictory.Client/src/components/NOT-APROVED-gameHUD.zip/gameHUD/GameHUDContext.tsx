import React, { createContext, useContext } from "react";


type GameplayState =
    | "idle"
    | "hunting"
    | "combat"
    | "reward";



interface GameHUDContextData
{
    state: GameplayState;

    setState:
        (state: GameplayState) => void;
}



const GameHUDContext =
    createContext<GameHUDContextData | null>(null);



interface GameHUDProviderProps
{
    children: React.ReactNode;

    state: GameplayState;

    setState:
        (state: GameplayState) => void;
}



export function GameHUDProvider(
{
    children,

    state,

    setState

}: GameHUDProviderProps)
{
    return (
        <GameHUDContext.Provider

            value={{
                state,

                setState
            }}

        >

            {children}

        </GameHUDContext.Provider>
    );
}



export function useGameHUD()
{
    const context =
        useContext(GameHUDContext);


    if (!context)
    {
        throw new Error(
            "useGameHUD must be used inside GameHUDProvider"
        );
    }


    return context;
}