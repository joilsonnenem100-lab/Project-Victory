interface Props {
    completed?: number;
    total?: number;
}

export default function CharacterAchievementProgressPanel({ completed = 0, total = 0 }: Props) {
    return (
        <section>
            Achievements: {completed}/{total}
        </section>
    );
}
