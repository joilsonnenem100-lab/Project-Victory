interface HUDDividerProps
{
    title?: string;
}



export default function HUDDivider(
{
    title = ""

}: HUDDividerProps)
{
    return (
        <div
            style={{
                borderBottom:
                    "1px solid #444",

                margin:
                    "10px 0",

                paddingBottom:
                    "5px"
            }}
        >

            {
                title &&

                <h3>
                    {title}
                </h3>
            }

        </div>
    );
}