interface Props {
    entries?: string[];
}

export default function CombatLogPanel({ entries = [] }: Props) {
    return (
        <section>
            <h3>Combat Log</h3>
            {entries.map((entry, index) => (
                <p key={index}>{entry}</p>
            ))}
        </section>
    );
}
