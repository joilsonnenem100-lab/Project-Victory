interface Props {
    item?: string;
}

export default function EquipmentEquipActionPanel({ item = '-' }: Props) {
    return (
        <section>
            Equip: {item}
        </section>
    );
}
