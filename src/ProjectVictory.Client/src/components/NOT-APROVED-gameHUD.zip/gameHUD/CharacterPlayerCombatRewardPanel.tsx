interface Props {
    experience?: number;
    rewards?: string[];
}

export default function CharacterPlayerCombatRewardPanel({ experience = 0, rewards = [] }: Props) {
    return (
        <section>
            <p>Experience: {experience}</p>
            {rewards.map((reward, index) => (
                <p key={index}>{reward}</p>
            ))}
        </section>
    );
}
