interface Props {
    event?: string;
}

export default function CharacterPlayerCombatEventPanel({ event = '-' }: Props) {
    return (
        <section>
            Event: {event}
        </section>
    );
}
