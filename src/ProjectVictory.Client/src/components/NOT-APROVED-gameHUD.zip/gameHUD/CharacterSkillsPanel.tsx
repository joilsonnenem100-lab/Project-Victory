interface Props {
    skills?: string[];
}

export default function CharacterSkillsPanel({ skills = [] }: Props) {
    return (
        <section>
            {skills.map((skill, index) => (
                <p key={index}>{skill}</p>
            ))}
        </section>
    );
}
