interface Props {
    damage?: number;
    critical?: number;
}

export default function CharacterCombatEnemyDamageSummaryPanel({ damage = 0, critical = 0 }: Props) {
    return (
        <section>
            <p>Damage: {damage}</p>
            <p>Critical: {critical}</p>
        </section>
    );
}
