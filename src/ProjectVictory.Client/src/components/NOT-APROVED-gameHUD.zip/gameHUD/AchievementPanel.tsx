interface Props {
    achievements?: string[];
}

export default function AchievementPanel({ achievements = [] }: Props) {
    return (
        <section>
            {achievements.map((achievement, index) => (
                <p key={index}>{achievement}</p>
            ))}
        </section>
    );
}
