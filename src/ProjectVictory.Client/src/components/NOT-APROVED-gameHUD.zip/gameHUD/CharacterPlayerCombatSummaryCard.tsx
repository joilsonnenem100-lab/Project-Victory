interface Props {
    name?: string;
    health?: number;
    status?: string;
}

export default function CharacterPlayerCombatSummaryCard({ name = '-', health = 0, status = '-' }: Props) {
    return (
        <section>
            <p>{name}</p>
            <p>Health: {health}</p>
            <p>Status: {status}</p>
        </section>
    );
}
