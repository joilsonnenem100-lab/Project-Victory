interface Props {
    current?: number;
    total?: number;
}

export default function CharacterCombatWaveProgressPanel({ current = 0, total = 0 }: Props) {
    return (
        <section>
            Progress: {current}/{total}
        </section>
    );
}
