export function mapHUDData(data: unknown) {
    return data;
}
