interface Props {
    name?: string;
    level?: number;
}

export default function CharacterOverviewPanel({ name = '-', level = 1 }: Props) {
    return (
        <section>
            <h3>{name}</h3>
            <p>Level: {level}</p>
        </section>
    );
}
