import React from "react";


interface GameHUDTabPanelProps
{
    title?: string;

    children?: React.ReactNode;
}



export default function GameHUDTabPanel(
{
    title,

    children

}: GameHUDTabPanelProps)
{
    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "10px",

                width:
                    "100%"
            }}
        >

            {
                title &&

                <h3>
                    {title}
                </h3>
            }



            <div>
                {children}
            </div>


        </section>
    );
}