interface Props {
    criticalChance?: number;
    criticalDamage?: number;
}

export default function CombatCriticalPanel({criticalChance = 0, criticalDamage = 0}: Props) {
    return (
        <section>
            <p>Critical Chance: {criticalChance}</p>
            <p>Critical Damage: {criticalDamage}</p>
        </section>
    );
}
