interface Props {
    ability?: string;
    remaining?: number;
}

export default function CharacterCombatCooldownPanel({ ability = '-', remaining = 0 }: Props) {
    return (
        <section>
            {ability}: {remaining}s
        </section>
    );
}
