interface Props {
    effects?: string[];
}

export default function CombatStatusEffectPanel({ effects = [] }: Props) {
    return (
        <section>
            {effects.map((effect, index) => (
                <p key={index}>{effect}</p>
            ))}
        </section>
    );
}
