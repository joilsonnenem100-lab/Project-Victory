interface Props {
    name?: string;
    current?: number;
    maximum?: number;
}

export default function CharacterPlayerResourceBarPanel({ name = '-', current = 0, maximum = 0 }: Props) {
    return (
        <section>
            {name}: {current}/{maximum}
        </section>
    );
}
