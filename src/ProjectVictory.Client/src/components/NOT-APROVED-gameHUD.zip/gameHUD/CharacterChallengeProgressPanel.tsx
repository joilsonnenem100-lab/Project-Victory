interface Props {
    completed?: number;
    total?: number;
}

export default function CharacterChallengeProgressPanel({ completed = 0, total = 0 }: Props) {
    return (
        <section>
            Challenges: {completed}/{total}
        </section>
    );
}
