interface EnemyHealthBarProps
{
    enemyName?: string;

    currentHealth?: number;

    maximumHealth?: number;
}



export default function EnemyHealthBar(
{
    enemyName = "-",

    currentHealth = 0,

    maximumHealth = 0

}: EnemyHealthBarProps)
{
    const percentage =
        maximumHealth > 0
            ? Math.min(
                100,
                (currentHealth / maximumHealth) * 100
            )
            : 0;


    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "10px",

                width:
                    "100%"
            }}
        >

            <h3>
                {enemyName}
            </h3>


            <div
                style={{
                    border:
                        "1px solid #333",

                    height:
                        "20px",

                    width:
                        "100%"
                }}
            >

                <div
                    style={{
                        width:
                            `${percentage}%`,

                        height:
                            "100%",

                        background:
                            "#555"
                    }}
                />

            </div>


            <p>
                {currentHealth}
                /
                {maximumHealth}
            </p>


        </section>
    );
}