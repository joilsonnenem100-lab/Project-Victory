interface Props {
    current?: number;
    nextLevel?: number;
}

export default function CharacterPlayerExperiencePanel({ current = 0, nextLevel = 0 }: Props) {
    return (
        <section>
            Experience: {current}/{nextLevel}
        </section>
    );
}
