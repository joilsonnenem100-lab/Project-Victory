interface Props {
    current?: number;
    required?: number;
}

export default function ExperienceBarPanel({ current = 0, required = 0 }: Props) {
    return (
        <section>
            Experience: {current}/{required}
        </section>
    );
}
