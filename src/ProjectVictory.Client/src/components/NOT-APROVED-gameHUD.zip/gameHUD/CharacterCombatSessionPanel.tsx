interface Props {
    duration?: number;
    active?: boolean;
}

export default function CharacterCombatSessionPanel({ duration = 0, active = false }: Props) {
    return (
        <section>
            {active ? `Combat Session: ${duration}s` : "Inactive"}
        </section>
    );
}
