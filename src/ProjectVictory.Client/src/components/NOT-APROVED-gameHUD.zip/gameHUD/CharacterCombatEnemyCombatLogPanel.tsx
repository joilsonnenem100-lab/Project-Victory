interface Props {
    logs?: string[];
}

export default function CharacterCombatEnemyCombatLogPanel({ logs = [] }: Props) {
    return (
        <section>
            {logs.map((log, index) => (
                <p key={index}>{log}</p>
            ))}
        </section>
    );
}
