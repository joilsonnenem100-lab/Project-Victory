interface Props {
    name?: string;
    level?: number;
    status?: string;
}

export default function CharacterPlayerOverviewPanel({ name = '-', level = 0, status = '-' }: Props) {
    return (
        <section>
            <p>Name: {name}</p>
            <p>Level: {level}</p>
            <p>Status: {status}</p>
        </section>
    );
}
