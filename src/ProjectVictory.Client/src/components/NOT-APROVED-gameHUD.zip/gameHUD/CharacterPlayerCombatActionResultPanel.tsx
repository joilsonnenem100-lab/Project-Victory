interface Props {
    result?: string;
}

export default function CharacterPlayerCombatActionResultPanel({ result = '-' }: Props) {
    return (
        <section>
            Action Result: {result}
        </section>
    );
}
