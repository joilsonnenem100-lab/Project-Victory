interface Props {
    effects?: string[];
}

export default function CharacterStatusEffectSummaryPanel({ effects = [] }: Props) {
    return (
        <section>
            {effects.map((effect, index) => (
                <p key={index}>{effect}</p>
            ))}
        </section>
    );
}
