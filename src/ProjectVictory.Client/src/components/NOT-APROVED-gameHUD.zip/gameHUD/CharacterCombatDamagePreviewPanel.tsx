interface Props {
    damage?: number;
    type?: string;
}

export default function CharacterCombatDamagePreviewPanel({ damage = 0, type = '-' }: Props) {
    return (
        <section>
            <p>Damage: {damage}</p>
            <p>Type: {type}</p>
        </section>
    );
}
