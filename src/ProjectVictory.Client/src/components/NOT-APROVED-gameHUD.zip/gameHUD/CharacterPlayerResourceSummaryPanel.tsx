interface Props {
    resources?: Record<string, number>;
}

export default function CharacterPlayerResourceSummaryPanel({ resources = {} }: Props) {
    return (
        <section>
            {Object.entries(resources).map(([key, value]) => (
                <p key={key}>{key}: {value}</p>
            ))}
        </section>
    );
}
