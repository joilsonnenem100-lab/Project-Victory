interface Props {
    rank?: number;
}

export default function CharacterRankingPanel({ rank = 0 }: Props) {
    return (
        <section>
            Rank: {rank}
        </section>
    );
}
