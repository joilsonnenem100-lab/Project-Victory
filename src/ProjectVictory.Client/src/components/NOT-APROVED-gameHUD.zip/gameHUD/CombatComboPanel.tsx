interface Props {
    combo?: number;
}

export default function CombatComboPanel({ combo = 0 }: Props) {
    return (
        <section>
            Combo: {combo}
        </section>
    );
}
