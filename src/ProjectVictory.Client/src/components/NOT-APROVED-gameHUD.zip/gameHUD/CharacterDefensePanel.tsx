interface Props {
    defense?: number;
    armor?: number;
}

export default function CharacterDefensePanel({ defense = 0, armor = 0 }: Props) {
    return (
        <section>
            <p>Defense: {defense}</p>
            <p>Armor: {armor}</p>
        </section>
    );
}
