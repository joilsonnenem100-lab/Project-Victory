interface Props {
    encounters?: string[];
}

export default function CharacterCombatEncounterHistoryPanel({ encounters = [] }: Props) {
    return (
        <section>
            {encounters.map((encounter, index) => (
                <p key={index}>{encounter}</p>
            ))}
        </section>
    );
}
