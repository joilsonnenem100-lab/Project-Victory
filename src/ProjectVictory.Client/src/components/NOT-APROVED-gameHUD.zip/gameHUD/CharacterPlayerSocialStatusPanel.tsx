interface Props {
    status?: string;
}

export default function CharacterPlayerSocialStatusPanel({ status = '-' }: Props) {
    return (
        <section>
            Social Status: {status}
        </section>
    );
}
