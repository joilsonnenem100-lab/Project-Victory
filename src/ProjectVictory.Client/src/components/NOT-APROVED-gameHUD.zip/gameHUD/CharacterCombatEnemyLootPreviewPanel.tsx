interface Props {
    items?: string[];
}

export default function CharacterCombatEnemyLootPreviewPanel({ items = [] }: Props) {
    return (
        <section>
            {items.map((item, index) => (
                <p key={index}>{item}</p>
            ))}
        </section>
    );
}
