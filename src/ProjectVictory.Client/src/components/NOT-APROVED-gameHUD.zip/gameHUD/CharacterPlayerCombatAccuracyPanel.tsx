interface Props {
    accuracy?: number;
}

export default function CharacterPlayerCombatAccuracyPanel({ accuracy = 0 }: Props) {
    return (
        <section>
            Accuracy: {accuracy}
        </section>
    );
}
