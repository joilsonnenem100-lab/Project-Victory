interface CombatStatusPanelProps
{
    active?: boolean;

    enemyName?: string;

    enemyHealth?: number;

    enemyMaxHealth?: number;
}



export default function CombatStatusPanel(
{
    active = false,

    enemyName = "-",

    enemyHealth = 0,

    enemyMaxHealth = 0

}: CombatStatusPanelProps)
{
    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "15px",

                width:
                    "100%"
            }}
        >

            <h3>
                Combat Status
            </h3>


            {
                active

                ?

                (
                    <>
                        <p>
                            Enemy:
                            {" "}
                            {enemyName}
                        </p>


                        <p>
                            HP:
                            {" "}
                            {enemyHealth}
                            /
                            {enemyMaxHealth}
                        </p>
                    </>
                )

                :

                (
                    <p>
                        No active combat.
                    </p>
                )
            }


        </section>
    );
}