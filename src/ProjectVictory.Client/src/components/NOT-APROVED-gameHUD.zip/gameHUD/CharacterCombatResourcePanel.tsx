interface Props {
    energy?: number;
    stamina?: number;
}

export default function CharacterCombatResourcePanel({ energy = 0, stamina = 0 }: Props) {
    return (
        <section>
            <p>Energy: {energy}</p>
            <p>Stamina: {stamina}</p>
        </section>
    );
}
