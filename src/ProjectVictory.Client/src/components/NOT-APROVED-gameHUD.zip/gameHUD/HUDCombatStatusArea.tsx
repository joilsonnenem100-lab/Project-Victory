interface Props {
    status?: string;
}

export default function HUDCombatStatusArea(
{
    status = "Waiting"

}: Props)
{
    return (
        <section>
            <h3>Combat Status</h3>
            <p>{status}</p>
        </section>
    );
}
