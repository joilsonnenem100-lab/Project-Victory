interface Props {
    role?: string;
}

export default function CharacterPlayerRolePanel({ role = '-' }: Props) {
    return (
        <section>
            Role: {role}
        </section>
    );
}
