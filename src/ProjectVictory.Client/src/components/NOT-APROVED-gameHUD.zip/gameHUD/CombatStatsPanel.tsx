interface Props {
    damage?: number;
    defense?: number;
}

export default function CombatStatsPanel({ damage = 0, defense = 0 }: Props) {
    return (
        <section>
            <p>Damage: {damage}</p>
            <p>Defense: {defense}</p>
        </section>
    );
}
