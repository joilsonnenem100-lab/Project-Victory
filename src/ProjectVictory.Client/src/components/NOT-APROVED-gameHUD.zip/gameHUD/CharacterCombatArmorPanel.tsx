interface Props {
    armor?: number;
}

export default function CharacterCombatArmorPanel({ armor = 0 }: Props) {
    return (
        <section>
            Armor: {armor}
        </section>
    );
}
