import React from "react";

import GameHUD from "./GameHUD";


interface GameHUDShellProps
{
    children?: React.ReactNode;


    character?:
    {
        name?: string;

        level?: number;

        experience?: number;
    };


    inventoryItems?: string[];

    equipmentSlots?: string[];
}



export default function GameHUDShell(
{
    children,

    character,

    inventoryItems,

    equipmentSlots

}: GameHUDShellProps)
{
    return (
        <GameHUD

            character={
                character
            }

            inventoryItems={
                inventoryItems
            }

            equipmentSlots={
                equipmentSlots
            }

        >

            {children}

        </GameHUD>
    );
}