interface Props {
    current?: number;
    maximum?: number;
}

export default function EnemyHealthPanel({ current = 0, maximum = 0 }: Props) {
    return (
        <section>
            Health: {current}/{maximum}
        </section>
    );
}
