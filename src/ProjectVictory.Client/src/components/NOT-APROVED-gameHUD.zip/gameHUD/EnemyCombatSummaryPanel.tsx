interface Props {
    summary?: string;
}

export default function EnemyCombatSummaryPanel({ summary = '-' }: Props) {
    return (
        <section>
            Summary: {summary}
        </section>
    );
}
