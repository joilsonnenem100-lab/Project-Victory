interface GameHUDLoadingProps
{
    message?: string;
}



export default function GameHUDLoading(
{
    message = "Loading game..."

}: GameHUDLoadingProps)
{
    return (
        <section
            style={{
                display:
                    "flex",

                alignItems:
                    "center",

                justifyContent:
                    "center",

                height:
                    "100%",

                width:
                    "100%",

                border:
                    "1px solid #444"
            }}
        >

            <h2>
                {message}
            </h2>


        </section>
    );
}