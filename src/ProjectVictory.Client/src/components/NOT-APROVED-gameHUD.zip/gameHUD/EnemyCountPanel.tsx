interface Props {
    count?: number;
}

export default function EnemyCountPanel({ count = 0 }: Props) {
    return (
        <section>
            Enemies: {count}
        </section>
    );
}
