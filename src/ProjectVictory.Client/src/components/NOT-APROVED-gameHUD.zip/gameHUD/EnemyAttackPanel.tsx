interface Props {
    attacks?: string[];
}

export default function EnemyAttackPanel({ attacks = [] }: Props) {
    return (
        <section>
            {attacks.map((attack, index) => (
                <p key={index}>{attack}</p>
            ))}
        </section>
    );
}
