interface Props {
    level?: number;
    experience?: number;
}

export default function CharacterPlayerCombatProgressionPanel({ level = 0, experience = 0 }: Props) {
    return (
        <section>
            <p>Level: {level}</p>
            <p>Experience: {experience}</p>
        </section>
    );
}
