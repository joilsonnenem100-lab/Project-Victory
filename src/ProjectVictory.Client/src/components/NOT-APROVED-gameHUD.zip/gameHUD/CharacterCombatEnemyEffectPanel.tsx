interface Props {
    effects?: string[];
}

export default function CharacterCombatEnemyEffectPanel({ effects = [] }: Props) {
    return (
        <section>
            {effects.map((effect, index) => (
                <p key={index}>{effect}</p>
            ))}
        </section>
    );
}
