interface Props {
    physical?: number;
    magical?: number;
    critical?: number;
}

export default function CharacterDamageBreakdownPanel({ physical = 0, magical = 0, critical = 0 }: Props) {
    return (
        <section>
            <p>Physical: {physical}</p>
            <p>Magical: {magical}</p>
            <p>Critical: {critical}</p>
        </section>
    );
}
