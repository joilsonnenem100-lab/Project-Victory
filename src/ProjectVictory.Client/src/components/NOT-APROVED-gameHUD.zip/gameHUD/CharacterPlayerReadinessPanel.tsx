interface Props {
    ready?: boolean;
}

export default function CharacterPlayerReadinessPanel({ ready = false }: Props) {
    return (
        <section>
            {ready ? "Ready" : "Not Ready"}
        </section>
    );
}
