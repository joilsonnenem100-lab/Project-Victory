export default function HUDCombatStatePlaceholder()
{
    return (
        <section>
            <h3>Combat Simulation</h3>
            <p>Reserved State</p>
        </section>
    );
}
