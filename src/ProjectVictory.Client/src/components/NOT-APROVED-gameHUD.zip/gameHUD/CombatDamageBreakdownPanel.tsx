interface Props {
    dealt?: number;
    received?: number;
}

export default function CombatDamageBreakdownPanel({ dealt = 0, received = 0 }: Props) {
    return (
        <section>
            <p>Dealt: {dealt}</p>
            <p>Received: {received}</p>
        </section>
    );
}
