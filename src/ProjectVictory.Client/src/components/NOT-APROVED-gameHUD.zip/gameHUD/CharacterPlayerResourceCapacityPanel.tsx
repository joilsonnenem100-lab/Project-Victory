interface Props {
    current?: number;
    maximum?: number;
}

export default function CharacterPlayerResourceCapacityPanel({ current = 0, maximum = 0 }: Props) {
    return (
        <section>
            Capacity: {current}/{maximum}
        </section>
    );
}
