interface Props {
    relationships?: Record<string, number>;
}

export default function CharacterPlayerRelationshipPanel({ relationships = {} }: Props) {
    return (
        <section>
            {Object.entries(relationships).map(([key, value]) => (
                <p key={key}>{key}: {value}</p>
            ))}
        </section>
    );
}
