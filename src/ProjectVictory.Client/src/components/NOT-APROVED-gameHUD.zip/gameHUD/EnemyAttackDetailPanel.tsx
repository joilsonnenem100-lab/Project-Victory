interface Props {
    attack?: string;
    description?: string;
}

export default function EnemyAttackDetailPanel({ attack = '-', description = '' }: Props) {
    return (
        <section>
            <p>{attack}</p>
            <p>{description}</p>
        </section>
    );
}
