interface Props {
    onAttack?: () => void;
    onDefend?: () => void;
}

export default function CombatActionBar({onAttack, onDefend}: Props) {
    return (
        <div>
            <button onClick={onAttack}>Attack</button>
            <button onClick={onDefend}>Defend</button>
        </div>
    );
}
