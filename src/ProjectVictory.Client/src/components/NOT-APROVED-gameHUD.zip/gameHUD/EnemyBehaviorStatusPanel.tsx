interface Props {
    behavior?: string;
}

export default function EnemyBehaviorStatusPanel({ behavior = '-' }: Props) {
    return (
        <section>
            Behavior: {behavior}
        </section>
    );
}
