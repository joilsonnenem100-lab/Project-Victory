interface Props {
    health?: number;
    mana?: number;
    stamina?: number;
}

export default function CharacterResourceSummaryPanel({ health = 0, mana = 0, stamina = 0 }: Props) {
    return (
        <section>
            <p>Health: {health}</p>
            <p>Mana: {mana}</p>
            <p>Stamina: {stamina}</p>
        </section>
    );
}
