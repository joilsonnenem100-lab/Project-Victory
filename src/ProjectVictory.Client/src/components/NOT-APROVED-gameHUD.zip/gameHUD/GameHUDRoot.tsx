interface Props {
    children?: React.ReactNode;
}

export default function GameHUDRoot({ children }: Props)
{
    return (
        <main>
            {children}
        </main>
    );
}
