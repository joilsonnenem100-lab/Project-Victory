interface Props {
    status?: string;
}

export default function GameplayStatusPanel({ status = '-' }: Props) {
    return (
        <section>
            Status: {status}
        </section>
    );
}
