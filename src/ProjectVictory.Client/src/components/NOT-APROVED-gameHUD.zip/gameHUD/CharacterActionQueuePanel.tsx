interface Props {
    actions?: string[];
}

export default function CharacterActionQueuePanel({ actions = [] }: Props) {
    return (
        <section>
            {actions.map((action, index) => (
                <p key={index}>{action}</p>
            ))}
        </section>
    );
}
