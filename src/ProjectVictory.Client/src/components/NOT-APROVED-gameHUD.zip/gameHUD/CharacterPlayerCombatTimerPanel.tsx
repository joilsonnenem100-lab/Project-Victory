interface Props {
    elapsed?: number;
    remaining?: number;
}

export default function CharacterPlayerCombatTimerPanel({ elapsed = 0, remaining = 0 }: Props) {
    return (
        <section>
            <p>Elapsed: {elapsed}s</p>
            <p>Remaining: {remaining}s</p>
        </section>
    );
}
