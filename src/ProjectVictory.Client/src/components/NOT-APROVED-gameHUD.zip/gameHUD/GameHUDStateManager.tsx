import React, { useState } from "react";


type GameplayState =
    | "idle"
    | "hunting"
    | "combat"
    | "reward";



interface GameHUDStateManagerProps
{
    children?:
        (
            state: GameplayState,

            setState:
                (state: GameplayState) => void

        ) => React.ReactNode;
}



export default function GameHUDStateManager(
{
    children

}: GameHUDStateManagerProps)
{
    const [state, setState] =
        useState<GameplayState>("idle");


    return (
        <>

            {
                children?.(
                    state,

                    setState
                )
            }

        </>
    );
}