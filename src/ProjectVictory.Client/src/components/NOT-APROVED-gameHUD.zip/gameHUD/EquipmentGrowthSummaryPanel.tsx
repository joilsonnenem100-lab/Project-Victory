interface Props {
    powerIncrease?: number;
}

export default function EquipmentGrowthSummaryPanel({ powerIncrease = 0 }: Props) {
    return (
        <section>
            Power Increase: +{powerIncrease}
        </section>
    );
}
