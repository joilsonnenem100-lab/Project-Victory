interface Props {
    pattern?: string;
}

export default function CharacterCombatEnemyPatternPanel({ pattern = '-' }: Props) {
    return (
        <section>
            Pattern: {pattern}
        </section>
    );
}
