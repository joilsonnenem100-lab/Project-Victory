interface Props {
    enemy?: string;
    status?: string;
}

export default function CharacterCombatEnemyStatusPanel({ enemy = '-', status = '-' }: Props) {
    return (
        <section>
            <p>Enemy: {enemy}</p>
            <p>Status: {status}</p>
        </section>
    );
}
