interface Props {
    goal?: string;
}

export default function CharacterPlayerGoalPanel({ goal = '-' }: Props) {
    return (
        <section>
            Goal: {goal}
        </section>
    );
}
