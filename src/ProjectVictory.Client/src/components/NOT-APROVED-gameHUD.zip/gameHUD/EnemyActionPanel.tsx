interface Props {
    action?: string;
}

export default function EnemyActionPanel({ action = '-' }: Props) {
    return (
        <section>
            Action: {action}
        </section>
    );
}
