interface Props {
    enemyName?: string;
    status?: string;
}

export default function HUDCombatSimulationArea(
{
    enemyName = "-",
    status = "Waiting"

}: Props)
{
    return (
        <section>
            <h3>Combat Simulation</h3>
            <p>{enemyName}</p>
            <p>{status}</p>
        </section>
    );
}
