export default function HUDGameAreaPlaceholder()
{
    return (
        <section>
            <h3>Game Area</h3>
        </section>
    );
}
