interface Props {
    arena?: string;
}

export default function CharacterCombatArenaPanel({ arena = '-' }: Props) {
    return (
        <section>
            Arena: {arena}
        </section>
    );
}
