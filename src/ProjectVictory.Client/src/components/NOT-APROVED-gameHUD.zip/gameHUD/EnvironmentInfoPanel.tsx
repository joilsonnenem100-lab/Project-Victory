interface Props {
    weather?: string;
    time?: string;
}

export default function EnvironmentInfoPanel({ weather = '-', time = '-' }: Props) {
    return (
        <section>
            <p>{weather}</p>
            <p>{time}</p>
        </section>
    );
}
