interface Props {
    modifiers?: string[];
}

export default function CombatModifierPanel({modifiers = []}: Props) {
    return (
        <section>
            {modifiers.map((modifier, index) => (
                <p key={index}>{modifier}</p>
            ))}
        </section>
    );
}
