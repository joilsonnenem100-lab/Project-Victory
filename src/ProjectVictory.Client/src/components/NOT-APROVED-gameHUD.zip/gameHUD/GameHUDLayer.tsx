import React from "react";


interface GameHUDLayerProps
{
    children?: React.ReactNode;

    position?:
        | "top"
        | "center"
        | "bottom"
        | "left"
        | "right";
}



export default function GameHUDLayer(
{
    children,

    position = "center"

}: GameHUDLayerProps)
{
    const alignment =
    {
        top:
            {
                top: "10px",
                left: "50%",
                transform: "translateX(-50%)"
            },

        center:
            {
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)"
            },

        bottom:
            {
                bottom: "10px",
                left: "50%",
                transform: "translateX(-50%)"
            },

        left:
            {
                left: "10px",
                top: "50%",
                transform: "translateY(-50%)"
            },

        right:
            {
                right: "10px",
                top: "50%",
                transform: "translateY(-50%)"
            }
    };


    return (
        <div
            style={{
                position:
                    "absolute",

                ...alignment[position],

                zIndex:
                    10
            }}
        >

            {children}

        </div>
    );
}