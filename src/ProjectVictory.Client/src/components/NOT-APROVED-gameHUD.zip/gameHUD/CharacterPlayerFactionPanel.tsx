interface Props {
    faction?: string;
}

export default function CharacterPlayerFactionPanel({ faction = '-' }: Props) {
    return (
        <section>
            Faction: {faction}
        </section>
    );
}
