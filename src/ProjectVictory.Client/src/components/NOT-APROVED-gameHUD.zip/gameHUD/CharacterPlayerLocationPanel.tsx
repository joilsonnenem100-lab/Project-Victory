interface Props {
    location?: string;
}

export default function CharacterPlayerLocationPanel({ location = '-' }: Props) {
    return (
        <section>
            Location: {location}
        </section>
    );
}
