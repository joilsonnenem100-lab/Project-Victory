interface Props {
    hint?: string;
}

export default function HelpHintPanel({ hint = '' }: Props) {
    return (
        <section>
            {hint}
        </section>
    );
}
