interface Props {
    status?: string;
    effects?: string[];
}

export default function CharacterCombatEnemyStatusSummaryPanel({ status = '-', effects = [] }: Props) {
    return (
        <section>
            <p>Status: {status}</p>
            {effects.map((effect, index) => (
                <p key={index}>{effect}</p>
            ))}
        </section>
    );
}
