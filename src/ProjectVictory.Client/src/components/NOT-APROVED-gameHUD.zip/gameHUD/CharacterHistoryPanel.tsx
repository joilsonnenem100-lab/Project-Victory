interface Props {
    events?: string[];
}

export default function CharacterHistoryPanel({ events = [] }: Props) {
    return (
        <section>
            {events.map((event, index) => (
                <p key={index}>{event}</p>
            ))}
        </section>
    );
}
