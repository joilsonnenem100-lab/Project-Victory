interface GameplayContextPanelProps
{
    title?: string;

    description?: string;

    action?: string;
}



export default function GameplayContextPanel(
{
    title = "Gameplay",

    description = "",

    action = ""

}: GameplayContextPanelProps)
{
    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "15px",

                width:
                    "100%"
            }}
        >

            <h2>
                {title}
            </h2>


            {
                description &&

                <p>
                    {description}
                </p>
            }



            {
                action &&

                <p>
                    Action:
                    {" "}
                    {action}
                </p>
            }


        </section>
    );
}