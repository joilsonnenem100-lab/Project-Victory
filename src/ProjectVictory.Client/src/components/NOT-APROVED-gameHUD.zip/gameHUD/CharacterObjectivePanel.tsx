interface Props {
    objectives?: string[];
}

export default function CharacterObjectivePanel({ objectives = [] }: Props) {
    return (
        <section>
            {objectives.map((objective, index) => (
                <p key={index}>{objective}</p>
            ))}
        </section>
    );
}
