interface Props {
    total?: number;
    average?: number;
}

export default function CharacterCombatDamageSummaryPanel({ total = 0, average = 0 }: Props) {
    return (
        <section>
            <p>Total Damage: {total}</p>
            <p>Average Damage: {average}</p>
        </section>
    );
}
