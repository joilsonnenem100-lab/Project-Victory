interface Props {
    phase?: string;
}

export default function EnemyPhasePanel({ phase = '-' }: Props) {
    return (
        <section>
            Phase: {phase}
        </section>
    );
}
