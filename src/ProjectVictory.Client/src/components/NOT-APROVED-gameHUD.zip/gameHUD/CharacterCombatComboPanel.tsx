interface Props {
    combo?: number;
}

export default function CharacterCombatComboPanel({ combo = 0 }: Props) {
    return (
        <section>
            Combo: {combo}
        </section>
    );
}
