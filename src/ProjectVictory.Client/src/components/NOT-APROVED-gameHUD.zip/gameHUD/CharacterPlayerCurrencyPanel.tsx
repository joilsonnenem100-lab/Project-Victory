interface Props {
    amount?: number;
}

export default function CharacterPlayerCurrencyPanel({ amount = 0 }: Props) {
    return (
        <section>
            Currency: {amount}
        </section>
    );
}
