interface Props {
    turns?: number[];
}

export default function CharacterCombatTurnHistoryPanel({ turns = [] }: Props) {
    return (
        <section>
            {turns.map((turn, index) => (
                <p key={index}>Turn: {turn}</p>
            ))}
        </section>
    );
}
