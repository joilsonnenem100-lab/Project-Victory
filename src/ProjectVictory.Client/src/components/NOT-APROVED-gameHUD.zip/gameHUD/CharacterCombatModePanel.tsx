interface Props {
    mode?: string;
}

export default function CharacterCombatModePanel({ mode = '-' }: Props) {
    return (
        <section>
            Mode: {mode}
        </section>
    );
}
