interface Props {
    cooldown?: number;
}

export default function CombatAbilityCooldownPanel({ cooldown = 0 }: Props) {
    return (
        <section>
            Cooldown: {cooldown}s
        </section>
    );
}
