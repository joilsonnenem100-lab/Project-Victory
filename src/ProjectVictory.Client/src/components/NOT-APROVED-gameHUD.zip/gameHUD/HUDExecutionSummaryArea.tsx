interface Props {
    summary?: string;
}

export default function HUDExecutionSummaryArea(
{
    summary = ""

}: Props)
{
    return (
        <section>
            <h3>Execution Summary</h3>
            <p>{summary}</p>
        </section>
    );
}
