interface GameHUDWindowHeaderProps
{
    title?: string;

    onClose?: () => void;
}



export default function GameHUDWindowHeader(
{
    title = "",

    onClose

}: GameHUDWindowHeaderProps)
{
    return (
        <header
            style={{
                display:
                    "flex",

                justifyContent:
                    "space-between",

                alignItems:
                    "center",

                borderBottom:
                    "1px solid #444",

                paddingBottom:
                    "6px",

                marginBottom:
                    "8px"
            }}
        >

            <h3>
                {title}
            </h3>



            {
                onClose &&

                <button
                    onClick={
                        onClose
                    }
                >
                    X
                </button>
            }


        </header>
    );
}