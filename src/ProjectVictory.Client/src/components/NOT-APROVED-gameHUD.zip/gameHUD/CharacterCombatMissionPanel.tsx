interface Props {
    mission?: string;
}

export default function CharacterCombatMissionPanel({ mission = '-' }: Props) {
    return (
        <section>
            Mission: {mission}
        </section>
    );
}
