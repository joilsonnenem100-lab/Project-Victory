interface Props {
    challenges?: string[];
}

export default function CharacterChallengePanel({ challenges = [] }: Props) {
    return (
        <section>
            {challenges.map((challenge, index) => (
                <p key={index}>{challenge}</p>
            ))}
        </section>
    );
}
