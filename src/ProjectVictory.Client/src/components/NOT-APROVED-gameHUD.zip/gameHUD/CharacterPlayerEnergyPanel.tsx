interface Props {
    current?: number;
    maximum?: number;
}

export default function CharacterPlayerEnergyPanel({ current = 0, maximum = 0 }: Props) {
    return (
        <section>
            Energy: {current}/{maximum}
        </section>
    );
}
