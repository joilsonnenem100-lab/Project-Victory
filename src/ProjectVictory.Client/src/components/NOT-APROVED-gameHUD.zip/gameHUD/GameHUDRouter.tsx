import React from "react";

import GameHUD from "./GameHUD";


interface GameHUDRouterProps
{
    children?: React.ReactNode;


    character?:
    {
        name?: string;

        level?: number;

        experience?: number;
    };


    inventoryItems?: string[];

    equipmentSlots?: string[];


    state?:
        | "idle"
        | "hunting"
        | "combat"
        | "reward";


    messages?: string[];

    information?: React.ReactNode;
}



export default function GameHUDRouter(
{
    children,

    character,

    inventoryItems,

    equipmentSlots,

    messages,

    information

}: GameHUDRouterProps)
{
    return (
        <GameHUD

            character={
                character
            }

            inventoryItems={
                inventoryItems
            }

            equipmentSlots={
                equipmentSlots
            }

            messages={
                messages
            }

            information={
                information
            }

        >

            {children}

        </GameHUD>
    );
}