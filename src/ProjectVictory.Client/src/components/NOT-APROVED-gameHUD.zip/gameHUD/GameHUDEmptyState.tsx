interface GameHUDEmptyStateProps
{
    title?: string;

    message?: string;
}



export default function GameHUDEmptyState(
{
    title = "No Activity",

    message = "Waiting for player action."

}: GameHUDEmptyStateProps)
{
    return (
        <section
            style={{
                display:
                    "flex",

                flexDirection:
                    "column",

                alignItems:
                    "center",

                justifyContent:
                    "center",

                height:
                    "100%",

                width:
                    "100%",

                border:
                    "1px solid #444",

                padding:
                    "20px"
            }}
        >

            <h2>
                {title}
            </h2>


            <p>
                {message}
            </p>


        </section>
    );
}