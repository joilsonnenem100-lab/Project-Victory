interface Props {
    shield?: number;
}

export default function CharacterCombatEnemyShieldPanel({ shield = 0 }: Props) {
    return (
        <section>
            Shield: {shield}
        </section>
    );
}
