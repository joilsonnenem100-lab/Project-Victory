interface Props {
    power?: number;
}

export default function EquipmentPowerPanel({ power = 0 }: Props) {
    return (
        <section>
            Power: {power}
        </section>
    );
}
