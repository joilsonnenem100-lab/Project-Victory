interface GameHUDBackgroundProps
{
    children?: React.ReactNode;
}



export default function GameHUDBackground(
{
    children

}: GameHUDBackgroundProps)
{
    return (
        <div
            style={{
                width:
                    "100%",

                height:
                    "100%",

                background:
                    "#111",

                position:
                    "relative"
            }}
        >

            {children}

        </div>
    );
}