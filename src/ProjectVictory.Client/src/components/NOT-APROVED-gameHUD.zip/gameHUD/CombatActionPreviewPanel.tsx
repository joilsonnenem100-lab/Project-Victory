interface Props {
    preview?: string;
}

export default function CombatActionPreviewPanel({ preview = '-' }: Props) {
    return (
        <section>
            Preview: {preview}
        </section>
    );
}
