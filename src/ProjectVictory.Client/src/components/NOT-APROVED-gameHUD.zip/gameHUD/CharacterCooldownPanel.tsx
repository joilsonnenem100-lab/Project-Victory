interface Props {
    skill?: string;
    seconds?: number;
}

export default function CharacterCooldownPanel({ skill = '-', seconds = 0 }: Props) {
    return (
        <section>
            {skill}: {seconds}s
        </section>
    );
}
