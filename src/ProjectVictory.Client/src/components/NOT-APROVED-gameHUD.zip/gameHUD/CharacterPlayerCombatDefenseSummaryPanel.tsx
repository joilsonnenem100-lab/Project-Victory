interface Props {
    defense?: number;
    resistance?: number;
}

export default function CharacterPlayerCombatDefenseSummaryPanel({ defense = 0, resistance = 0 }: Props) {
    return (
        <section>
            <p>Defense: {defense}</p>
            <p>Resistance: {resistance}</p>
        </section>
    );
}
