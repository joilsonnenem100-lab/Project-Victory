interface Props {
    milestones?: string[];
}

export default function CharacterPlayerMilestonePanel({ milestones = [] }: Props) {
    return (
        <section>
            {milestones.map((milestone, index) => (
                <p key={index}>{milestone}</p>
            ))}
        </section>
    );
}
