interface Props {
    statistics?: Record<string, number>;
}

export default function CharacterCombatEnemyStatisticsPanel({ statistics = {} }: Props) {
    return (
        <section>
            {Object.entries(statistics).map(([key, value]) => (
                <p key={key}>{key}: {value}</p>
            ))}
        </section>
    );
}
