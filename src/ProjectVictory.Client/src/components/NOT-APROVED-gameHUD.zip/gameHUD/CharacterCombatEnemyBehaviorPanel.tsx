interface Props {
    behavior?: string;
}

export default function CharacterCombatEnemyBehaviorPanel({ behavior = '-' }: Props) {
    return (
        <section>
            Behavior: {behavior}
        </section>
    );
}
