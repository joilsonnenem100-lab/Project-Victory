interface Props {
    slot?: string;
    item?: string;
}

export default function EquipmentSlot({ slot = '-', item = '-' }: Props) {
    return (
        <section>
            <p>{slot}</p>
            <p>{item}</p>
        </section>
    );
}
