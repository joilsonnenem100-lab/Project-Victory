interface Props {
    phase?: string;
}

export default function CombatPhasePanel({ phase = '-' }: Props) {
    return (
        <section>
            Phase: {phase}
        </section>
    );
}
