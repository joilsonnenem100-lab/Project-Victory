interface Props {
    cost?: number;
    material?: string;
}

export default function EquipmentUpgradeCostPanel({ cost = 0, material = '-' }: Props) {
    return (
        <section>
            <p>Material: {material}</p>
            <p>Cost: {cost}</p>
        </section>
    );
}
