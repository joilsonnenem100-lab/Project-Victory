interface Props {
    origin?: string;
}

export default function CharacterPlayerOriginPanel({ origin = '-' }: Props) {
    return (
        <section>
            Origin: {origin}
        </section>
    );
}
