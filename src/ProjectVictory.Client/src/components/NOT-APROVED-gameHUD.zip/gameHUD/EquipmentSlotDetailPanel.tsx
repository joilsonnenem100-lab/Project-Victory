interface Props {
    slot?: string;
    item?: string;
}

export default function EquipmentSlotDetailPanel({ slot = '-', item = '-' }: Props) {
    return (
        <section>
            <p>Slot: {slot}</p>
            <p>Item: {item}</p>
        </section>
    );
}
