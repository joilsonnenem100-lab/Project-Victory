interface Props {
    equipment?: string[];
}

export default function HUDEquipmentArea(
{
    equipment = []

}: Props)
{
    return (
        <section>
            <h3>Equipment</h3>
            {equipment.length === 0 && (
                <p>Reserved</p>
            )}
        </section>
    );
}
