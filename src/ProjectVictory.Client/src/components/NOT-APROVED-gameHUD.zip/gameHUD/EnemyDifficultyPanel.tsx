interface Props {
    difficulty?: string;
}

export default function EnemyDifficultyPanel({ difficulty = '-' }: Props) {
    return (
        <section>
            Difficulty: {difficulty}
        </section>
    );
}
