interface Props {
    state?: string;
}

export default function CharacterCombatEnemyAIStatePanel({ state = '-' }: Props) {
    return (
        <section>
            AI State: {state}
        </section>
    );
}
