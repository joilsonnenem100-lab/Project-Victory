interface Props {
    message?: string;
}

export default function CombatDefeatPanel({ message = '-' }: Props) {
    return (
        <section>
            Defeat: {message}
        </section>
    );
}
