interface Props {
    active?: boolean;
}

export default function CombatSimulationPanel({ active = false }: Props) {
    return (
        <section>
            Combat Simulation: {active ? "Running" : "Idle"}
        </section>
    );
}
