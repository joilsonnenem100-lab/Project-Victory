interface Props {
    summary?: string;
}

export default function CombatSummaryPanel({ summary = '-' }: Props) {
    return (
        <section>
            Summary: {summary}
        </section>
    );
}
