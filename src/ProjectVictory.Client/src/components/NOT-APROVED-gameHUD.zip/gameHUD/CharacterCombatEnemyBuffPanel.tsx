interface Props {
    buffs?: string[];
}

export default function CharacterCombatEnemyBuffPanel({ buffs = [] }: Props) {
    return (
        <section>
            {buffs.map((buff, index) => (
                <p key={index}>{buff}</p>
            ))}
        </section>
    );
}
