interface Props {
    progress?: string;
}

export default function CharacterPlayerCombatProgressPanel({ progress = '-' }: Props) {
    return (
        <section>
            Combat Progress: {progress}
        </section>
    );
}
