interface Props {
    events?: string[];
}

export default function EventTrackerPanel({ events = [] }: Props) {
    return (
        <section>
            {events.map((event, index) => (
                <p key={index}>{event}</p>
            ))}
        </section>
    );
}
