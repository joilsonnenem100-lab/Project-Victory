interface Props {
    history?: string[];
}

export default function CombatHistoryPanel({ history = [] }: Props) {
    return (
        <section>
            {history.map((item, index) => (
                <p key={index}>{item}</p>
            ))}
        </section>
    );
}
