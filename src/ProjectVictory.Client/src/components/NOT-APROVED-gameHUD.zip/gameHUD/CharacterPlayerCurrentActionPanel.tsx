interface Props {
    action?: string;
}

export default function CharacterPlayerCurrentActionPanel({ action = '-' }: Props) {
    return (
        <section>
            Current Action: {action}
        </section>
    );
}
