interface Props {
    specialization?: string;
}

export default function CharacterPlayerSpecializationPanel({ specialization = '-' }: Props) {
    return (
        <section>
            Specialization: {specialization}
        </section>
    );
}
