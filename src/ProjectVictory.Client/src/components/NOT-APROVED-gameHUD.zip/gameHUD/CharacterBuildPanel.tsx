interface Props {
    build?: string;
}

export default function CharacterBuildPanel({ build = '-' }: Props) {
    return (
        <section>
            Build: {build}
        </section>
    );
}
