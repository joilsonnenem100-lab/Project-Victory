interface Props {
    category?: string;
}

export default function CharacterCombatEnemyCategoryPanel({ category = '-' }: Props) {
    return (
        <section>
            Category: {category}
        </section>
    );
}
