interface Props {
    rewards?: string[];
}

export default function EnemyRewardPreviewPanel({ rewards = [] }: Props) {
    return (
        <section>
            {rewards.map((reward, index) => (
                <p key={index}>{reward}</p>
            ))}
        </section>
    );
}
