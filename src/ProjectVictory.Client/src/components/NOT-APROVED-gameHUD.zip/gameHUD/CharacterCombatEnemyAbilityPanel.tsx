interface Props {
    abilities?: string[];
}

export default function CharacterCombatEnemyAbilityPanel({ abilities = [] }: Props) {
    return (
        <section>
            {abilities.map((ability, index) => (
                <p key={index}>{ability}</p>
            ))}
        </section>
    );
}
