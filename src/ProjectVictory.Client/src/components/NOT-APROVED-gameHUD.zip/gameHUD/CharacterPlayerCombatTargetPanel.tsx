interface Props {
    target?: string;
}

export default function CharacterPlayerCombatTargetPanel({ target = '-' }: Props) {
    return (
        <section>
            Target: {target}
        </section>
    );
}
