interface Props {
    difficulty?: string;
}

export default function CharacterCombatEnemyDifficultyPanel({ difficulty = '-' }: Props) {
    return (
        <section>
            Difficulty: {difficulty}
        </section>
    );
}
