interface Props {
    onStartHunt?: () => void;
}

export default function HUDActionPanel(
{
    onStartHunt

}: Props)
{
    return (
        <section>
            <button onClick={onStartHunt}>
                Start Hunt
            </button>
        </section>
    );
}
