import React from "react";

import TopStatusBar from "./TopStatusBar";
import RightPlayerPanel from "./RightPlayerPanel";
import ActionBar from "./ActionBar";
import GameLogPanel from "./GameLogPanel";
import InformationPanel from "./InformationPanel";
import MainGameplayArea from "./MainGameplayArea";


interface GameHUDLayoutProps
{
    children?: React.ReactNode;

    topStatus?: React.ReactNode;

    rightPanel?: React.ReactNode;

    actions?: string[];

    logMessages?: string[];

    information?: React.ReactNode;
}


export default function GameHUDLayout(
{
    children,

    topStatus,

    rightPanel,

    actions,

    logMessages,

    information

}: GameHUDLayoutProps)
{
    return (
        <main
            style={{
                display:
                    "grid",

                gridTemplateRows:
                    "90px 1fr 120px",

                gridTemplateColumns:
                    "1fr 300px",

                height:
                    "100vh",

                width:
                    "100%"
            }}
        >

            <header
                style={{
                    gridColumn:
                        "1 / 3"
                }}
            >

                {
                    topStatus
                    ??
                    (
                        <TopStatusBar />
                    )
                }

            </header>



            <MainGameplayArea>

                {children}

            </MainGameplayArea>



            <aside>

                {
                    rightPanel
                    ??
                    (
                        <RightPlayerPanel />
                    )
                }

            </aside>



            <footer
                style={{
                    gridColumn:
                        "1 / 3",

                    display:
                        "grid",

                    gridTemplateColumns:
                        "1fr 1fr"
                }}
            >

                <GameLogPanel

                    messages={
                        logMessages
                    }

                />


                <InformationPanel

                    content={
                        information
                    }

                />


                <div
                    style={{
                        gridColumn:
                            "1 / 3"
                    }}
                >

                    <ActionBar

                        actions={
                            actions
                        }

                    />

                </div>


            </footer>


        </main>
    );
}