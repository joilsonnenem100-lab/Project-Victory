interface Props {
    cost?: number;
    resource?: string;
}

export default function CombatActionCostPanel({ cost = 0, resource = '-' }: Props) {
    return (
        <section>
            {resource}: {cost}
        </section>
    );
}
