interface Props {
    children?: React.ReactNode;
}

export default function HUDCentralArea({ children }: Props)
{
    return (
        <section>
            {children}
        </section>
    );
}
