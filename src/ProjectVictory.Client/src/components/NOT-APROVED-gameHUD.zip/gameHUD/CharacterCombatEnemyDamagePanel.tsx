interface Props {
    damage?: number;
}

export default function CharacterCombatEnemyDamagePanel({ damage = 0 }: Props) {
    return (
        <section>
            Enemy Damage: {damage}
        </section>
    );
}
