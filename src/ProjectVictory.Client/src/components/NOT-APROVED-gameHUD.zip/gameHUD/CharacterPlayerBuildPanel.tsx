interface Props {
    build?: string;
}

export default function CharacterPlayerBuildPanel({ build = '-' }: Props) {
    return (
        <section>
            Build: {build}
        </section>
    );
}
