interface Props {
    events?: string[];
}

export default function HUDEventLogArea(
{
    events = []

}: Props)
{
    return (
        <section>
            <h3>Events</h3>

            {events.length === 0 && (
                <p>No events</p>
            )}

            {events.map((event, index) => (
                <p key={index}>
                    {event}
                </p>
            ))}
        </section>
    );
}
