interface Props {
    outcome?: string;
}

export default function CombatOutcomePanel({ outcome = '-' }: Props) {
    return (
        <section>
            Outcome: {outcome}
        </section>
    );
}
