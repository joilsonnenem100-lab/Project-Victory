interface Props {
    stamina?: number;
    energy?: number;
}

export default function CombatResourcePanel({ stamina = 0, energy = 0 }: Props) {
    return (
        <section>
            <p>Stamina: {stamina}</p>
            <p>Energy: {energy}</p>
        </section>
    );
}
