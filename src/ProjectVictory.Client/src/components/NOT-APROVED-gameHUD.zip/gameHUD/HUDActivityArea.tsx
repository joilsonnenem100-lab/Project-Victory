interface Props {
    activity?: string;
}

export default function HUDActivityArea(
{
    activity = ""

}: Props)
{
    return (
        <section>
            <h3>Activity</h3>
            <p>{activity}</p>
        </section>
    );
}
