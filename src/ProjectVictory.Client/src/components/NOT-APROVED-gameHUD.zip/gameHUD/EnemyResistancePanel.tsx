interface Props {
    resistance?: Record<string, number>;
}

export default function EnemyResistancePanel({ resistance = {} }: Props) {
    return (
        <section>
            {Object.entries(resistance).map(([key, value]) => (
                <p key={key}>{key}: {value}</p>
            ))}
        </section>
    );
}
