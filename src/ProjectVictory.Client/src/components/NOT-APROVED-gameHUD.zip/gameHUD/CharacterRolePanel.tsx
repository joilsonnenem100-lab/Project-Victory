interface Props {
    role?: string;
}

export default function CharacterRolePanel({ role = '-' }: Props) {
    return (
        <section>
            Role: {role}
        </section>
    );
}
