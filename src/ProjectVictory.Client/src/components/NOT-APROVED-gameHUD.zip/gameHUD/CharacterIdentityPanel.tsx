interface CharacterIdentityPanelProps
{
    name?: string;

    className?: string;
}



export default function CharacterIdentityPanel(
{
    name = "-",

    className = "-"

}: CharacterIdentityPanelProps)
{
    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "10px",

                width:
                    "100%"
            }}
        >

            <h3>
                Character
            </h3>


            <p>
                Name:
                {" "}
                {name}
            </p>


            <p>
                Class:
                {" "}
                {className}
            </p>


        </section>
    );
}