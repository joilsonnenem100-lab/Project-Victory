interface Props {
    quests?: string[];
}

export default function CharacterQuestPanel({ quests = [] }: Props) {
    return (
        <section>
            {quests.map((quest, index) => (
                <p key={index}>{quest}</p>
            ))}
        </section>
    );
}
