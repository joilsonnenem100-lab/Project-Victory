interface Props {
    level?: number;
}

export default function CharacterPlayerLevelPanel({ level = 0 }: Props) {
    return (
        <section>
            Level: {level}
        </section>
    );
}
