interface Props {
    level?: number;
}

export default function CharacterCombatEnemyLevelPanel({ level = 0 }: Props) {
    return (
        <section>
            Enemy Level: {level}
        </section>
    );
}
