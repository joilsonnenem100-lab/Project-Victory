interface Props {
    progress?: number;
}

export default function HUDCombatProgressArea(
{
    progress = 0

}: Props)
{
    return (
        <section>
            <h3>Combat Progress</h3>
            <p>{progress}%</p>
        </section>
    );
}
