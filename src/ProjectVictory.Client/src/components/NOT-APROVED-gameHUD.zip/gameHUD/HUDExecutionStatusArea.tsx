interface Props {
    status?: string;
}

export default function HUDExecutionStatusArea(
{
    status = "Idle"

}: Props)
{
    return (
        <section>
            <h3>Execution Status</h3>
            <p>{status}</p>
        </section>
    );
}
