interface Props {
    balance?: number;
}

export default function BankPanel({ balance = 0 }: Props) {
    return (
        <section>
            Balance: {balance}
        </section>
    );
}
