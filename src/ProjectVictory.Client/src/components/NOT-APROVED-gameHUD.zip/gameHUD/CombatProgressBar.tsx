interface Props {
    progress?: number;
}

export default function CombatProgressBar({ progress = 0 }: Props) {
    return (
        <section>
            Combat Progress: {progress}%
        </section>
    );
}
