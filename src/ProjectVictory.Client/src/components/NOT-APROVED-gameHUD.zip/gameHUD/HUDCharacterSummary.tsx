interface Props {
    name?: string;
    level?: number;
}

export default function HUDCharacterSummary(
{
    name = "-",
    level = 0

}: Props)
{
    return (
        <section>
            <h3>Character</h3>
            <p>{name}</p>
            <p>Level: {level}</p>
        </section>
    );
}
