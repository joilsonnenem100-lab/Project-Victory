import React from "react";


interface GameHUDSlotProps
{
    children?: React.ReactNode;

    label?: string;
}



export default function GameHUDSlot(
{
    children,

    label

}: GameHUDSlotProps)
{
    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "8px",

                minWidth:
                    "80px",

                minHeight:
                    "40px",

                display:
                    "flex",

                flexDirection:
                    "column",

                alignItems:
                    "center",

                justifyContent:
                    "center"
            }}
        >

            {
                label &&

                <small>
                    {label}
                </small>
            }



            {children}

        </section>
    );
}