interface Props {
    ability?: string;
    description?: string;
}

export default function CombatAbilityDetailPanel({ ability = '-', description = '' }: Props) {
    return (
        <section>
            <p>{ability}</p>
            <p>{description}</p>
        </section>
    );
}
