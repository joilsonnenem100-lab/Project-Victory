interface Props {
    history?: number[];
}

export default function CharacterCombatDamageHistoryPanel({ history = [] }: Props) {
    return (
        <section>
            {history.map((damage, index) => (
                <p key={index}>Damage: {damage}</p>
            ))}
        </section>
    );
}
