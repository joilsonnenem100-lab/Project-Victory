interface Props {
    message?: string;
}

export default function CombatVictoryPanel({ message = '-' }: Props) {
    return (
        <section>
            Victory: {message}
        </section>
    );
}
