interface Props {
    achievements?: string[];
}

export default function CharacterPlayerAchievementPanel({ achievements = [] }: Props) {
    return (
        <section>
            {achievements.map((achievement, index) => (
                <p key={index}>{achievement}</p>
            ))}
        </section>
    );
}
