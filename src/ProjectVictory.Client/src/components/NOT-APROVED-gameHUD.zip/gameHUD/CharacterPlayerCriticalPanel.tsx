interface Props {
    chance?: number;
    multiplier?: number;
}

export default function CharacterPlayerCriticalPanel({ chance = 0, multiplier = 0 }: Props) {
    return (
        <section>
            <p>Critical Chance: {chance}</p>
            <p>Multiplier: {multiplier}</p>
        </section>
    );
}
