interface Props {
    name?: string;
}

export default function EquipmentItemPreview({ name = '-' }: Props) {
    return (
        <section>
            Item: {name}
        </section>
    );
}
