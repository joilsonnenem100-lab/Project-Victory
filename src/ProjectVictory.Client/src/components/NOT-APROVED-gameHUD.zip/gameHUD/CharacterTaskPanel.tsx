interface Props {
    tasks?: string[];
}

export default function CharacterTaskPanel({ tasks = [] }: Props) {
    return (
        <section>
            {tasks.map((task, index) => (
                <p key={index}>{task}</p>
            ))}
        </section>
    );
}
