interface Props {
    mode?: string;
}

export default function CharacterPlayerCombatModePanel({ mode = '-' }: Props) {
    return (
        <section>
            Combat Mode: {mode}
        </section>
    );
}
