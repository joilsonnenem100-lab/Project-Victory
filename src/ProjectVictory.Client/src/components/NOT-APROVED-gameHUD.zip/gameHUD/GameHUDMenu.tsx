interface GameHUDMenuProps
{
    onCharacter?: () => void;

    onInventory?: () => void;

    onSettings?: () => void;
}



export default function GameHUDMenu(
{
    onCharacter,

    onInventory,

    onSettings

}: GameHUDMenuProps)
{
    return (
        <section
            style={{
                display:
                    "flex",

                flexDirection:
                    "column",

                gap:
                    "8px",

                border:
                    "1px solid #444",

                padding:
                    "10px",

                width:
                    "100%"
            }}
        >

            <h3>
                Menu
            </h3>


            <button
                onClick={
                    onCharacter
                }
            >
                Character
            </button>



            <button
                onClick={
                    onInventory
                }
            >
                Inventory
            </button>



            <button
                onClick={
                    onSettings
                }
            >
                Settings
            </button>


        </section>
    );
}