import React from "react";

interface Props {
    children?: React.ReactNode;
}

export default function GameplayCenterFrame({children}: Props) {
    return (
        <main>
            {children}
        </main>
    );
}
