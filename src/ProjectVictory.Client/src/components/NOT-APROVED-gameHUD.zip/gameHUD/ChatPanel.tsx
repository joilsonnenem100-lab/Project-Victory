interface Props {
    messages?: string[];
}

export default function ChatPanel({ messages = [] }: Props) {
    return (
        <section>
            {messages.map((message, index) => (
                <p key={index}>{message}</p>
            ))}
        </section>
    );
}
