interface Props {
    experience?: number;
    gold?: number;
}

export default function CharacterCombatRewardPanel({ experience = 0, gold = 0 }: Props) {
    return (
        <section>
            <p>Experience: {experience}</p>
            <p>Gold: {gold}</p>
        </section>
    );
}
