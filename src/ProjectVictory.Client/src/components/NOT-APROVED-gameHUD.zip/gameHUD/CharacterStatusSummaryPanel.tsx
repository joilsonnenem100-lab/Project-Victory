interface Props {
    health?: number;
    mana?: number;
    level?: number;
}

export default function CharacterStatusSummaryPanel({ health = 0, mana = 0, level = 1 }: Props) {
    return (
        <section>
            <p>Level: {level}</p>
            <p>HP: {health}</p>
            <p>MP: {mana}</p>
        </section>
    );
}
