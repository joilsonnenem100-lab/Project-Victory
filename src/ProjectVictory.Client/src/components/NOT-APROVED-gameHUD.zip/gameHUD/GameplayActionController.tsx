interface GameplayActionControllerProps
{
    state?:
        | "idle"
        | "hunting"
        | "combat"
        | "reward";


    onStartHunt?: () => void;

    onAttack?: () => void;

    onCollectReward?: () => void;
}



export default function GameplayActionController(
{
    state = "idle",

    onStartHunt,

    onAttack,

    onCollectReward

}: GameplayActionControllerProps)
{
    return (
        <section
            style={{
                display:
                    "flex",

                gap:
                    "10px",

                border:
                    "1px solid #444",

                padding:
                    "10px"
            }}
        >

            {
                state === "idle" &&

                (
                    <button
                        onClick={
                            onStartHunt
                        }
                    >
                        Start Hunt
                    </button>
                )
            }



            {
                state === "hunting" &&

                (
                    <button
                        onClick={
                            onAttack
                        }
                    >
                        Attack
                    </button>
                )
            }



            {
                state === "combat" &&

                (
                    <button
                        onClick={
                            onAttack
                        }
                    >
                        Attack
                    </button>
                )
            }



            {
                state === "reward" &&

                (
                    <button
                        onClick={
                            onCollectReward
                        }
                    >
                        Collect Reward
                    </button>
                )
            }


        </section>
    );
}