interface Props {
    weaknesses?: string[];
}

export default function CharacterCombatEnemyWeaknessSummaryPanel({ weaknesses = [] }: Props) {
    return (
        <section>
            {weaknesses.map((weakness, index) => (
                <p key={index}>{weakness}</p>
            ))}
        </section>
    );
}
