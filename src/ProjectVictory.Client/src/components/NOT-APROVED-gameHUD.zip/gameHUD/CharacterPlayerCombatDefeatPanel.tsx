interface Props {
    defeated?: boolean;
}

export default function CharacterPlayerCombatDefeatPanel({ defeated = false }: Props) {
    return (
        <section>
            {defeated ? "Defeated" : "Active"}
        </section>
    );
}
