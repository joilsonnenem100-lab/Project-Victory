interface ActivityProgressPanelProps
{
    current?: number;

    maximum?: number;

    label?: string;
}



export default function ActivityProgressPanel(
{
    current = 0,

    maximum = 0,

    label = "Progress"

}: ActivityProgressPanelProps)
{
    const percentage =
        maximum > 0
            ? Math.min(
                100,
                (current / maximum) * 100
            )
            : 0;


    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "10px",

                width:
                    "100%"
            }}
        >

            <h3>
                {label}
            </h3>


            <div
                style={{
                    border:
                        "1px solid #333",

                    height:
                        "18px",

                    width:
                        "100%"
                }}
            >

                <div
                    style={{
                        width:
                            `${percentage}%`,

                        height:
                            "100%",

                        background:
                            "#555"
                    }}
                />

            </div>


            <p>
                {current}
                /
                {maximum}
            </p>


        </section>
    );
}