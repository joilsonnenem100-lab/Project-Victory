interface Props {
    target?: string;
    status?: string;
}

export default function CharacterCombatTargetStatusPanel({ target = '-', status = '-' }: Props) {
    return (
        <section>
            <p>Target: {target}</p>
            <p>Status: {status}</p>
        </section>
    );
}
