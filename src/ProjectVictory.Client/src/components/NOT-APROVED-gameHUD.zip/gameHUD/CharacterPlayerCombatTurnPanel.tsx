interface Props {
    current?: number;
}

export default function CharacterPlayerCombatTurnPanel({ current = 0 }: Props) {
    return (
        <section>
            Turn: {current}
        </section>
    );
}
