interface Props {
    intent?: string;
}

export default function EnemyCombatIntentPanel({ intent = '-' }: Props) {
    return (
        <section>
            Intent: {intent}
        </section>
    );
}
