interface Props {
    encounter?: string;
}

export default function CharacterPlayerCombatEncounterPanel({ encounter = '-' }: Props) {
    return (
        <section>
            Encounter: {encounter}
        </section>
    );
}
