interface Props {
    action?: string;
    seconds?: number;
}

export default function ActionCooldownPanel({ action = '-', seconds = 0 }: Props) {
    return (
        <section>
            {action}: {seconds}s
        </section>
    );
}
