interface Props {
    target?: string;
}

export default function EnemyTargetPanel({ target = '-' }: Props) {
    return (
        <section>
            Target: {target}
        </section>
    );
}
