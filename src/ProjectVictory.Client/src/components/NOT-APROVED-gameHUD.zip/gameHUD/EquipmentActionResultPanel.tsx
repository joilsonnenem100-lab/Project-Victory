interface Props {
    message?: string;
}

export default function EquipmentActionResultPanel({ message = '-' }: Props) {
    return (
        <section>
            {message}
        </section>
    );
}
