interface Props {
    phase?: string;
}

export default function CharacterCombatPhasePanel({ phase = '-' }: Props) {
    return (
        <section>
            Combat Phase: {phase}
        </section>
    );
}
