interface Props {
    duration?: number;
    active?: boolean;
}

export default function CharacterPlayerCombatSessionPanel({ duration = 0, active = false }: Props) {
    return (
        <section>
            {active ? `Combat Duration: ${duration}s` : "No Active Combat"}
        </section>
    );
}
