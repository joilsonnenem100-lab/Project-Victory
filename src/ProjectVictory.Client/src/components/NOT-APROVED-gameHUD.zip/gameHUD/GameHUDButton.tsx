interface GameHUDButtonProps
{
    label?: string;

    onClick?: () => void;

    disabled?: boolean;
}



export default function GameHUDButton(
{
    label = "Action",

    onClick,

    disabled = false

}: GameHUDButtonProps)
{
    return (
        <button

            onClick={
                onClick
            }

            disabled={
                disabled
            }

            style={{
                padding:
                    "8px 16px",

                cursor:
                    disabled
                        ? "not-allowed"
                        : "pointer"
            }}

        >

            {label}

        </button>
    );
}