interface Props {
    amount?: number;
}

export default function HUDGoldArea({ amount = 0 }: Props)
{
    return (
        <section>
            <h3>Gold</h3>
            <p>{amount}</p>
        </section>
    );
}
