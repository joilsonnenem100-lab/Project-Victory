interface Props {
    message?: string;
}

export default function CharacterPlayerCombatAlertPanel({ message = '-' }: Props) {
    return (
        <section>
            Alert: {message}
        </section>
    );
}
