interface Props {
    progress?: string;
}

export default function CharacterPlayerProgressSummaryPanel({ progress = '-' }: Props) {
    return (
        <section>
            Progress: {progress}
        </section>
    );
}
