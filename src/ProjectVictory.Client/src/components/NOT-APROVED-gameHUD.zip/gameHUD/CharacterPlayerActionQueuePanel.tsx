interface Props {
    queue?: string[];
}

export default function CharacterPlayerActionQueuePanel({ queue = [] }: Props) {
    return (
        <section>
            {queue.map((action, index) => (
                <p key={index}>{action}</p>
            ))}
        </section>
    );
}
