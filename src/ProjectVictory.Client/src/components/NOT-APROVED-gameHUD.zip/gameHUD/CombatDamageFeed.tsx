interface Props {
    damages?: string[];
}

export default function CombatDamageFeed({ damages = [] }: Props) {
    return (
        <section>
            {damages.map((damage, index) => (
                <p key={index}>{damage}</p>
            ))}
        </section>
    );
}
