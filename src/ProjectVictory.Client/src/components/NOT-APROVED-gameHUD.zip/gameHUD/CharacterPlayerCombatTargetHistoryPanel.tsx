interface Props {
    targets?: string[];
}

export default function CharacterPlayerCombatTargetHistoryPanel({ targets = [] }: Props) {
    return (
        <section>
            {targets.map((target, index) => (
                <p key={index}>{target}</p>
            ))}
        </section>
    );
}
