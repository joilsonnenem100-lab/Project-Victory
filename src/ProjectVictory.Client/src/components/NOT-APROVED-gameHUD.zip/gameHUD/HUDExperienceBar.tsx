interface Props {
    current?: number;
    maximum?: number;
}

export default function HUDExperienceBar(
{
    current = 0,
    maximum = 0

}: Props)
{
    return (
        <section>
            <h3>Experience</h3>
            <span>
                {current} / {maximum}
            </span>
        </section>
    );
}
