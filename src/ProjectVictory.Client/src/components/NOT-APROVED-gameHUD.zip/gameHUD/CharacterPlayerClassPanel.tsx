interface Props {
    className?: string;
}

export default function CharacterPlayerClassPanel({ className = '-' }: Props) {
    return (
        <section>
            Class: {className}
        </section>
    );
}
