interface Props {
    stats?: Record<string, number>;
}

export default function EquipmentStatsSummaryPanel({ stats = {} }: Props) {
    return (
        <section>
            {Object.entries(stats).map(([key, value]) => (
                <p key={key}>{key}: {value}</p>
            ))}
        </section>
    );
}
