interface Props {
    chance?: number;
}

export default function CharacterCombatPredictionPanel({ chance = 0 }: Props) {
    return (
        <section>
            Prediction: {chance}%
        </section>
    );
}
