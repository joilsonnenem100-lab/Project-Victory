interface Props {
    efficiency?: number;
}

export default function CharacterPlayerCombatEfficiencyPanel({ efficiency = 0 }: Props) {
    return (
        <section>
            Efficiency: {efficiency}
        </section>
    );
}
