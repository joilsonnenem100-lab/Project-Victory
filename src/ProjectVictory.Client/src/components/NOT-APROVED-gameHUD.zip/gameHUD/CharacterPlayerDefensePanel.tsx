interface Props {
    defense?: number;
}

export default function CharacterPlayerDefensePanel({ defense = 0 }: Props) {
    return (
        <section>
            Defense: {defense}
        </section>
    );
}
