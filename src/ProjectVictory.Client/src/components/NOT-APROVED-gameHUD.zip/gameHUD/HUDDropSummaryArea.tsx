interface Props {
    itemCount?: number;
}

export default function HUDDropSummaryArea(
{
    itemCount = 0

}: Props)
{
    return (
        <section>
            <h3>Drop Summary</h3>
            <p>Items: {itemCount}</p>
        </section>
    );
}
