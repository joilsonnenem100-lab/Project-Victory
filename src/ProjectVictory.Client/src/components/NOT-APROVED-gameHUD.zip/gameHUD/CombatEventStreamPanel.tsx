interface Props {
    events?: string[];
}

export default function CombatEventStreamPanel({ events = [] }: Props) {
    return (
        <section>
            {events.map((event, index) => (
                <p key={index}>{event}</p>
            ))}
        </section>
    );
}
