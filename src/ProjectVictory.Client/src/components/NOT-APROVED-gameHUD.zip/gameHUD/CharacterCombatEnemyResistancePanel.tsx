interface Props {
    resistances?: Record<string, number>;
}

export default function CharacterCombatEnemyResistancePanel({ resistances = {} }: Props) {
    return (
        <section>
            {Object.entries(resistances).map(([key, value]) => (
                <p key={key}>{key}: {value}</p>
            ))}
        </section>
    );
}
