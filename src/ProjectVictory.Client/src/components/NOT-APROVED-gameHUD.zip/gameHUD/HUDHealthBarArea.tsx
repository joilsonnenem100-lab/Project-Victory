interface Props {
    current?: number;
    maximum?: number;
}

export default function HUDHealthBarArea({ current = 0, maximum = 0 }: Props)
{
    return (
        <section>
            <h3>Health</h3>
            <p>{current} / {maximum}</p>
        </section>
    );
}
