interface Props {
    enemy?: string;
    difficulty?: string;
}

export default function CharacterCombatEnemyPreviewPanel({ enemy = '-', difficulty = '-' }: Props) {
    return (
        <section>
            <p>Enemy: {enemy}</p>
            <p>Difficulty: {difficulty}</p>
        </section>
    );
}
