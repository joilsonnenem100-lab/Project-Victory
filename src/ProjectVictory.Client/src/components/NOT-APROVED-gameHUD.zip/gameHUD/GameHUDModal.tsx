import React from "react";


interface GameHUDModalProps
{
    title?: string;

    children?: React.ReactNode;

    visible?: boolean;

    onClose?: () => void;
}



export default function GameHUDModal(
{
    title = "",

    children,

    visible = false,

    onClose

}: GameHUDModalProps)
{
    if (!visible)
    {
        return null;
    }


    return (
        <div
            style={{
                position:
                    "fixed",

                top:
                    0,

                left:
                    0,

                width:
                    "100vw",

                height:
                    "100vh",

                display:
                    "flex",

                alignItems:
                    "center",

                justifyContent:
                    "center",

                background:
                    "rgba(0,0,0,0.5)"
            }}
        >

            <section
                style={{
                    border:
                        "1px solid #444",

                    background:
                        "#111",

                    padding:
                        "20px",

                    minWidth:
                        "300px"
                }}
            >

                <header
                    style={{
                        display:
                            "flex",

                        justifyContent:
                            "space-between"
                    }}
                >

                    <h2>
                        {title}
                    </h2>


                    {
                        onClose &&

                        <button
                            onClick={
                                onClose
                            }
                        >
                            X
                        </button>
                    }


                </header>



                <div>
                    {children}
                </div>


            </section>

        </div>
    );
}