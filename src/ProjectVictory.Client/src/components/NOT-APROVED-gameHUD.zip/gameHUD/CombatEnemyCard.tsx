interface Props {
    name?: string;
    hp?: number;
    maxHp?: number;
}

export default function CombatEnemyCard({name = "-", hp = 0, maxHp = 0}: Props) {
    return (
        <div>
            <h3>{name}</h3>
            <p>{hp}/{maxHp}</p>
        </div>
    );
}
