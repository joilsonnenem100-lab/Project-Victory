import React from "react";

import GameHUDContainer from "./GameHUDContainer";


interface GameHUDProps
{
    children?: React.ReactNode;


    character?:
    {
        name?: string;

        level?: number;

        experience?: number;
    };


    health?: number;

    maxHealth?: number;

    mana?: number;

    maxMana?: number;

    experience?: number;

    experiencePercent?: number;


    inventoryItems?: string[];

    equipmentSlots?: string[];


    actions?: string[];

    messages?: string[];

    information?: React.ReactNode;
}



export default function GameHUD(
{
    children,

    character,

    health,

    maxHealth,

    mana,

    maxMana,

    experience,

    experiencePercent,

    inventoryItems,

    equipmentSlots,

    actions,

    messages,

    information

}: GameHUDProps)
{
    return (
        <GameHUDContainer

            character={
                character
            }

            health={
                health
            }

            maxHealth={
                maxHealth
            }

            mana={
                mana
            }

            maxMana={
                maxMana
            }

            experience={
                experience
            }

            experiencePercent={
                experiencePercent
            }

            inventoryItems={
                inventoryItems
            }

            equipmentSlots={
                equipmentSlots
            }

            actions={
                actions
            }

            messages={
                messages
            }

            information={
                information
            }

        >

            {children}

        </GameHUDContainer>
    );
}