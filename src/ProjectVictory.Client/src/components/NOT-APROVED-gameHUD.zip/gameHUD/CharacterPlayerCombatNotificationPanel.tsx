interface Props {
    notifications?: string[];
}

export default function CharacterPlayerCombatNotificationPanel({ notifications = [] }: Props) {
    return (
        <section>
            {notifications.map((notification, index) => (
                <p key={index}>{notification}</p>
            ))}
        </section>
    );
}
