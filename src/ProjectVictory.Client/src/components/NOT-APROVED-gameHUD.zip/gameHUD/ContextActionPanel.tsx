interface Props {
    actions?: string[];
}

export default function ContextActionPanel({ actions = [] }: Props) {
    return (
        <section>
            {actions.map((action, index) => (
                <button key={index}>{action}</button>
            ))}
        </section>
    );
}
