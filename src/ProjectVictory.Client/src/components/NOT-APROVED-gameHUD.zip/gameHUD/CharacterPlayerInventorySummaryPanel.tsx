interface Props {
    used?: number;
    capacity?: number;
}

export default function CharacterPlayerInventorySummaryPanel({ used = 0, capacity = 0 }: Props) {
    return (
        <section>
            Inventory: {used}/{capacity}
        </section>
    );
}
