interface Props {
    faction?: string;
}

export default function CharacterFactionPanel({ faction = '-' }: Props) {
    return (
        <section>
            Faction: {faction}
        </section>
    );
}
