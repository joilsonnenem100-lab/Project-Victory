interface Props {
    value?: number;
}

export default function CharacterPlayerShieldPanel({ value = 0 }: Props) {
    return (
        <section>
            Shield: {value}
        </section>
    );
}
