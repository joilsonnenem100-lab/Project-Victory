interface Props {
    totalPower?: number;
}

export default function EquipmentPowerSummaryPanel({ totalPower = 0 }: Props) {
    return (
        <section>
            Total Power: {totalPower}
        </section>
    );
}
