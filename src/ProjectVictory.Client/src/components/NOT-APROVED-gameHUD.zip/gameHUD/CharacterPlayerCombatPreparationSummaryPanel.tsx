interface Props {
    preparation?: string;
}

export default function CharacterPlayerCombatPreparationSummaryPanel({ preparation = '-' }: Props) {
    return (
        <section>
            Preparation: {preparation}
        </section>
    );
}
