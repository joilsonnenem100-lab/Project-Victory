interface Props {
    activities?: string[];
}

export default function ActivityFeedPanel({ activities = [] }: Props) {
    return (
        <section>
            {activities.map((activity, index) => (
                <p key={index}>{activity}</p>
            ))}
        </section>
    );
}
