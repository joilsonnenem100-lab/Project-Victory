interface Props {
    equipment?: string[];
}

export default function EquipmentLoadoutSummaryPanel({ equipment = [] }: Props) {
    return (
        <section>
            {equipment.map((item, index) => (
                <p key={index}>{item}</p>
            ))}
        </section>
    );
}
