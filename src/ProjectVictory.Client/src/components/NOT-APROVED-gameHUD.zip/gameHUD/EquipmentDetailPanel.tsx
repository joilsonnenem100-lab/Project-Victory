interface Props {
    equipment?: string;
    stats?: string[];
}

export default function EquipmentDetailPanel({ equipment = '-', stats = [] }: Props) {
    return (
        <section>
            <h3>{equipment}</h3>
            {stats.map((stat, index) => (
                <p key={index}>{stat}</p>
            ))}
        </section>
    );
}
