interface Props {
    summary?: string;
}

export default function CombatSimulationSummary({ summary = '-' }: Props) {
    return (
        <section>
            Summary: {summary}
        </section>
    );
}
