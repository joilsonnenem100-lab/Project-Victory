interface Props {
    indicator?: string;
}

export default function CharacterPlayerCombatIndicatorPanel({ indicator = '-' }: Props) {
    return (
        <section>
            Indicator: {indicator}
        </section>
    );
}
