interface Props {
    status?: string;
}

export default function CharacterCombatStatusPanel({ status = '-' }: Props) {
    return (
        <section>
            Combat Status: {status}
        </section>
    );
}
