interface Props {
    total?: number;
    completed?: number;
}

export default function CharacterPlayerAchievementSummaryPanel({ total = 0, completed = 0 }: Props) {
    return (
        <section>
            Achievements: {completed}/{total}
        </section>
    );
}
