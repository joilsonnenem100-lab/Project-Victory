interface Props {
    count?: number;
}

export default function HUDExecutionCounterArea(
{
    count = 0

}: Props)
{
    return (
        <section>
            <h3>Executions</h3>
            <p>{count}</p>
        </section>
    );
}
