interface Props {
    preparation?: string;
}

export default function CharacterPlayerPreparationPanel({ preparation = '-' }: Props) {
    return (
        <section>
            Preparation: {preparation}
        </section>
    );
}
