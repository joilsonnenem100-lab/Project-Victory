interface Props {
    result?: string;
}

export default function CharacterPlayerCombatResultPanel({ result = '-' }: Props) {
    return (
        <section>
            Result: {result}
        </section>
    );
}
