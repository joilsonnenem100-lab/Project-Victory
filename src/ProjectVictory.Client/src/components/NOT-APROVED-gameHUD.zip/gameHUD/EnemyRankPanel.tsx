interface Props {
    rank?: string;
}

export default function EnemyRankPanel({ rank = '-' }: Props) {
    return (
        <section>
            Rank: {rank}
        </section>
    );
}
