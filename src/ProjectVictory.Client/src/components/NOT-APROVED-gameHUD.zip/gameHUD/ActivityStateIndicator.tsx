interface ActivityStateIndicatorProps
{
    state?:
        | "idle"
        | "hunting"
        | "combat"
        | "reward";
}



export default function ActivityStateIndicator(
{
    state = "idle"

}: ActivityStateIndicatorProps)
{
    const stateLabels =
    {
        idle:
            "Waiting",

        hunting:
            "Hunting",

        combat:
            "Combat Active",

        reward:
            "Reward Received"
    };


    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "10px",

                width:
                    "100%",

                textAlign:
                    "center"
            }}
        >

            <h3>
                Current State
            </h3>


            <p>
                {
                    stateLabels[state]
                }
            </p>


        </section>
    );
}