interface Props {
    milestones?: string[];
}

export default function CharacterPlayerCombatMilestonePanel({ milestones = [] }: Props) {
    return (
        <section>
            {milestones.map((milestone, index) => (
                <p key={index}>{milestone}</p>
            ))}
        </section>
    );
}
