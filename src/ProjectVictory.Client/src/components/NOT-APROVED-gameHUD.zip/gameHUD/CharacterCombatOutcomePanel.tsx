interface Props {
    outcome?: string;
    reward?: number;
}

export default function CharacterCombatOutcomePanel({ outcome = '-', reward = 0 }: Props) {
    return (
        <section>
            <p>{outcome}</p>
            <p>Reward: {reward}</p>
        </section>
    );
}
