interface Props {
    difficulty?: string;
}

export default function CharacterPlayerCombatDifficultyPanel({ difficulty = '-' }: Props) {
    return (
        <section>
            Difficulty: {difficulty}
        </section>
    );
}
