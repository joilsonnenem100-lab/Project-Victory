import React from "react";

import GameHeader from "./GameHeader";
import RightPlayerPanel from "./RightPlayerPanel";
import MainGameplayArea from "./MainGameplayArea";
import GameFooter from "./GameFooter";


interface GameHUDContainerProps
{
    children?: React.ReactNode;


    character?:
    {
        name?: string;

        level?: number;

        experience?: number;
    };


    health?: number;

    maxHealth?: number;

    mana?: number;

    maxMana?: number;

    experience?: number;

    experiencePercent?: number;


    inventoryItems?: string[];

    equipmentSlots?: string[];


    actions?: string[];

    messages?: string[];

    information?: React.ReactNode;
}



export default function GameHUDContainer(
{
    children,

    character,

    health,

    maxHealth,

    mana,

    maxMana,

    experience,

    experiencePercent,

    inventoryItems,

    equipmentSlots,

    actions,

    messages,

    information

}: GameHUDContainerProps)
{
    return (
        <main
            style={{
                display:
                    "grid",

                gridTemplateRows:
                    "90px 1fr 180px",

                gridTemplateColumns:
                    "1fr 320px",

                width:
                    "100vw",

                height:
                    "100vh",

                background:
                    "#111",

                color:
                    "#fff"
            }}
        >

            <div
                style={{
                    gridColumn:
                        "1 / 3"
                }}
            >

                <GameHeader

                    health={
                        health
                    }

                    maxHealth={
                        maxHealth
                    }

                    mana={
                        mana
                    }

                    maxMana={
                        maxMana
                    }

                    experience={
                        experience
                    }

                    experiencePercent={
                        experiencePercent
                    }

                />

            </div>



            <MainGameplayArea>

                {children}

            </MainGameplayArea>



            <RightPlayerPanel

                character={
                    character
                }

                inventoryItems={
                    inventoryItems
                }

                equipmentSlots={
                    equipmentSlots
                }

            />



            <div
                style={{
                    gridColumn:
                        "1 / 3"
                }}
            >

                <GameFooter

                    actions={
                        actions
                    }

                    messages={
                        messages
                    }

                    information={
                        information
                    }

                />

            </div>


        </main>
    );
}