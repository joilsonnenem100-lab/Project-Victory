interface Props {
    message?: string;
}

export default function GameplayMessagePanel({ message = '' }: Props) {
    return (
        <section>
            {message}
        </section>
    );
}
