interface Props {
    friends?: string[];
}

export default function CharacterSocialPanel({ friends = [] }: Props) {
    return (
        <section>
            {friends.map((friend, index) => (
                <p key={index}>{friend}</p>
            ))}
        </section>
    );
}
