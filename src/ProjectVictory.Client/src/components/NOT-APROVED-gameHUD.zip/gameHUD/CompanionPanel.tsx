interface Props {
    companions?: string[];
}

export default function CompanionPanel({ companions = [] }: Props) {
    return (
        <section>
            {companions.map((companion, index) => (
                <p key={index}>{companion}</p>
            ))}
        </section>
    );
}
