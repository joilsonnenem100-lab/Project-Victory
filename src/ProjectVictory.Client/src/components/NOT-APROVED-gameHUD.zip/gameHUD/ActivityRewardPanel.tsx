interface ActivityRewardPanelProps
{
    experience?: number;

    gold?: number;

    items?: string[];

    visible?: boolean;
}



export default function ActivityRewardPanel(
{
    experience = 0,

    gold = 0,

    items = [],

    visible = false

}: ActivityRewardPanelProps)
{
    if (!visible)
    {
        return null;
    }


    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "15px",

                width:
                    "100%"
            }}
        >

            <h2>
                Reward
            </h2>


            <p>
                Experience:
                {" "}
                {experience}
            </p>


            <p>
                Gold:
                {" "}
                {gold}
            </p>



            <h3>
                Items
            </h3>


            {
                items.length === 0

                ?

                (
                    <p>
                        No items received.
                    </p>
                )

                :

                (
                    <ul>
                        {
                            items.map(
                                (item, index) =>
                                (
                                    <li
                                        key={index}
                                    >
                                        {item}
                                    </li>
                                )
                            )
                        }
                    </ul>
                )
            }


        </section>
    );
}