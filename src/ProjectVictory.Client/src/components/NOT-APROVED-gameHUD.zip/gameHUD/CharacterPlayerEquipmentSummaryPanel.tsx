interface Props {
    equipped?: number;
    slots?: number;
}

export default function CharacterPlayerEquipmentSummaryPanel({ equipped = 0, slots = 0 }: Props) {
    return (
        <section>
            Equipment: {equipped}/{slots}
        </section>
    );
}
