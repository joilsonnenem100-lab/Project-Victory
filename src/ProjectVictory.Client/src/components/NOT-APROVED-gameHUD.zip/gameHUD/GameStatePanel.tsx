interface GameStatePanelProps
{
    state?: string;

    title?: string;

    data?: Record<string, unknown>;
}


export default function GameStatePanel(
{
    state = "Idle",

    title = "Gameplay",

    data = {}

}: GameStatePanelProps)
{
    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "15px",

                width:
                    "100%"
            }}
        >

            <h2>
                {title}
            </h2>


            <p>
                State:
                {" "}
                {state}
            </p>



            {
                Object.entries(data).map(
                    ([key, value]) =>
                    (
                        <p
                            key={key}
                        >
                            {key}:
                            {" "}
                            {String(value)}
                        </p>
                    )
                )
            }


        </section>
    );
}