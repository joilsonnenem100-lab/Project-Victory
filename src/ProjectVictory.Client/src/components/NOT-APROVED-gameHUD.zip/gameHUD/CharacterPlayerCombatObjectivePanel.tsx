interface Props {
    objective?: string;
}

export default function CharacterPlayerCombatObjectivePanel({ objective = '-' }: Props) {
    return (
        <section>
            Objective: {objective}
        </section>
    );
}
