interface Props {
    status?: string;
}

export default function HUDActivityStatusBadge(
{
    status = "Idle"

}: Props)
{
    return (
        <section>
            {status}
        </section>
    );
}
