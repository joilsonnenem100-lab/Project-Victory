interface ActivityTitlePanelProps
{
    title?: string;

    subtitle?: string;
}



export default function ActivityTitlePanel(
{
    title = "Ascendance Path",

    subtitle = ""

}: ActivityTitlePanelProps)
{
    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "15px",

                width:
                    "100%"
            }}
        >

            <h1>
                {title}
            </h1>


            {
                subtitle &&

                <p>
                    {subtitle}
                </p>
            }


        </section>
    );
}