interface Props {
    title?: string;
}

export default function CharacterTitlePanel({ title = '-' }: Props) {
    return (
        <section>
            Title: {title}
        </section>
    );
}
