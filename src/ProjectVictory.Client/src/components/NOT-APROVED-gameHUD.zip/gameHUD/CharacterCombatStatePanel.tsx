interface Props {
    state?: string;
}

export default function CharacterCombatStatePanel({ state = '-' }: Props) {
    return (
        <section>
            Combat State: {state}
        </section>
    );
}
