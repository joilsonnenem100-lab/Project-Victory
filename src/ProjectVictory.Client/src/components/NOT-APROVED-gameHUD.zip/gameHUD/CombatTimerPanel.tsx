interface Props {
    seconds?: number;
}

export default function CombatTimerPanel({ seconds = 0 }: Props) {
    return (
        <section>
            Combat Time: {seconds}s
        </section>
    );
}
