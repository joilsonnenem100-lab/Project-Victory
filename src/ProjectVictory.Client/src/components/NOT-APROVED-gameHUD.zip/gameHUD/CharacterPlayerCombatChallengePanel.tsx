interface Props {
    challenges?: string[];
}

export default function CharacterPlayerCombatChallengePanel({ challenges = [] }: Props) {
    return (
        <section>
            {challenges.map((challenge, index) => (
                <p key={index}>{challenge}</p>
            ))}
        </section>
    );
}
