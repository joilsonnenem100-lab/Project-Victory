interface Props {
    state?: string;
}

export default function CharacterPlayerCombatStatePanel({ state = '-' }: Props) {
    return (
        <section>
            Combat State: {state}
        </section>
    );
}
