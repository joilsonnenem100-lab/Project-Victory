interface Props {
    listings?: string[];
}

export default function AuctionPanel({ listings = [] }: Props) {
    return (
        <section>
            {listings.map((listing, index) => (
                <p key={index}>{listing}</p>
            ))}
        </section>
    );
}
