interface Props {
    status?: string;
    damage?: number;
}

export default function CharacterCombatSummaryPanel({ status = '-', damage = 0 }: Props) {
    return (
        <section>
            <p>Status: {status}</p>
            <p>Damage: {damage}</p>
        </section>
    );
}
