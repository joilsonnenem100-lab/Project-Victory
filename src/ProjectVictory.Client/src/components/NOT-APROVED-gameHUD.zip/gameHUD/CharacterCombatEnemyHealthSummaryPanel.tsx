interface Props {
    current?: number;
    maximum?: number;
}

export default function CharacterCombatEnemyHealthSummaryPanel({ current = 0, maximum = 0 }: Props) {
    return (
        <section>
            Enemy HP: {current}/{maximum}
        </section>
    );
}
