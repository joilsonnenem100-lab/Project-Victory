export type GameHUDState =
{
    mode:
        | "idle"
        | "hunting"
        | "combat"
        | "reward";


    location?: string;


    enemyName?: string;

    enemyCurrentHealth?: number;

    enemyMaximumHealth?: number;


    playerHealth?: number;


    experienceGained?: number;


    goldGained?: number;


    drops?: string[];
};



interface GameHUDStateProps
{
    state: GameHUDState;
}



export default function GameHUDStateView(
{
    state

}: GameHUDStateProps)
{
    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "15px",

                width:
                    "100%"
            }}
        >

            <h2>
                Game State
            </h2>


            <p>
                Mode:
                {" "}
                {state.mode}
            </p>


            {
                state.location &&

                <p>
                    Location:
                    {" "}
                    {state.location}
                </p>
            }



            {
                state.enemyName &&

                <>

                    <p>
                        Enemy:
                        {" "}
                        {state.enemyName}
                    </p>


                    <p>
                        Enemy HP:
                        {" "}
                        {state.enemyCurrentHealth}

                        /

                        {state.enemyMaximumHealth}
                    </p>

                </>

            }



            {
                state.playerHealth !== undefined &&

                <p>
                    Player HP:
                    {" "}
                    {state.playerHealth}
                </p>

            }



            {
                state.experienceGained !== undefined &&

                <p>
                    Experience:
                    {" "}
                    {state.experienceGained}
                </p>

            }



            {
                state.goldGained !== undefined &&

                <p>
                    Gold:
                    {" "}
                    {state.goldGained}
                </p>

            }



        </section>
    );
}