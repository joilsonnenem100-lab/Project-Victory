interface Props {
    drops?: string[];
}

export default function HUDDropListArea({ drops = [] }: Props)
{
    return (
        <section>
            <h3>Drops</h3>
            {drops.map((drop, index) => (
                <p key={index}>{drop}</p>
            ))}
        </section>
    );
}
