interface Props {
    targets?: string[];
}

export default function CombatTargetSelectionPanel({ targets = [] }: Props) {
    return (
        <section>
            {targets.map((target, index) => (
                <p key={index}>{target}</p>
            ))}
        </section>
    );
}
