interface Props {
    setName?: string;
    pieces?: number;
}

export default function EquipmentSetPanel({ setName = '-', pieces = 0 }: Props) {
    return (
        <section>
            <h3>{setName}</h3>
            <p>Pieces: {pieces}</p>
        </section>
    );
}
