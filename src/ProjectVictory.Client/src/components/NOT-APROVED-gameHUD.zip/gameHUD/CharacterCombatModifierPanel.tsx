interface Props {
    modifiers?: string[];
}

export default function CharacterCombatModifierPanel({ modifiers = [] }: Props) {
    return (
        <section>
            {modifiers.map((modifier, index) => (
                <p key={index}>{modifier}</p>
            ))}
        </section>
    );
}
