interface Props {
    history?: string[];
}

export default function EnemyCombatHistoryPanel({ history = [] }: Props) {
    return (
        <section>
            {history.map((item, index) => (
                <p key={index}>{item}</p>
            ))}
        </section>
    );
}
