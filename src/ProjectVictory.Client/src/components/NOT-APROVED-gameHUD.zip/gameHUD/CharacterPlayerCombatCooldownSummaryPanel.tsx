interface Props {
    cooldowns?: Record<string, number>;
}

export default function CharacterPlayerCombatCooldownSummaryPanel({ cooldowns = {} }: Props) {
    return (
        <section>
            {Object.entries(cooldowns).map(([key, value]) => (
                <p key={key}>{key}: {value}s</p>
            ))}
        </section>
    );
}
