interface Props {
    children?: React.ReactNode;
}

export default function HUDCentralContent({ children }: Props)
{
    return (
        <div>
            {children}
        </div>
    );
}
