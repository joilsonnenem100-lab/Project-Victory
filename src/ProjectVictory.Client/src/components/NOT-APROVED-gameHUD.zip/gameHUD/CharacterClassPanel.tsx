interface Props {
    className?: string;
}

export default function CharacterClassPanel({ className = '-' }: Props) {
    return (
        <section>
            Class: {className}
        </section>
    );
}
