interface Props {
    name?: string;
    level?: number;
}

export default function EnemyIdentityPanel({ name = '-', level = 0 }: Props) {
    return (
        <section>
            <p>{name}</p>
            <p>Level: {level}</p>
        </section>
    );
}
