interface Props {
    dealt?: number;
    received?: number;
}

export default function CombatDamageSummaryPanel({ dealt = 0, received = 0 }: Props) {
    return (
        <section>
            <p>Damage Dealt: {dealt}</p>
            <p>Damage Received: {received}</p>
        </section>
    );
}
