interface Props {
    turn?: number;
}

export default function CharacterCombatTurnPanel({ turn = 0 }: Props) {
    return (
        <section>
            Turn: {turn}
        </section>
    );
}
