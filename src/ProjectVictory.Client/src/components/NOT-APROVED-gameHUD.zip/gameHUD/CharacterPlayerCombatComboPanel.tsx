interface Props {
    combo?: number;
}

export default function CharacterPlayerCombatComboPanel({ combo = 0 }: Props) {
    return (
        <section>
            Combo: {combo}
        </section>
    );
}
