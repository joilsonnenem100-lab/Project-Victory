interface Props {
    type?: string;
}

export default function CharacterCombatEnemyTypePanel({ type = '-' }: Props) {
    return (
        <section>
            Enemy Type: {type}
        </section>
    );
}
