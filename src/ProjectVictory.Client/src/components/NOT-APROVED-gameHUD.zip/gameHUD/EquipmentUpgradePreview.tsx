interface Props {
    currentPower?: number;
    nextPower?: number;
}

export default function EquipmentUpgradePreview({ currentPower = 0, nextPower = 0 }: Props) {
    return (
        <section>
            <p>Current Power: {currentPower}</p>
            <p>Next Power: {nextPower}</p>
        </section>
    );
}
