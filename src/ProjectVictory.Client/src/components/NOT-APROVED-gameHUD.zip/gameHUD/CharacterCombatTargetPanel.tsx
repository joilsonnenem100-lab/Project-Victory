interface Props {
    target?: string;
    health?: number;
}

export default function CharacterCombatTargetPanel({ target = '-', health = 0 }: Props) {
    return (
        <section>
            <p>Target: {target}</p>
            <p>HP: {health}</p>
        </section>
    );
}
