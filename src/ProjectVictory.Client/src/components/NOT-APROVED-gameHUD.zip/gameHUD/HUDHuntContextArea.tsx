interface Props {
    huntName?: string;
    status?: string;
}

export default function HUDHuntContextArea(
{
    huntName = "-",
    status = "Idle"

}: Props)
{
    return (
        <section>
            <h3>Hunt Context</h3>
            <p>{huntName}</p>
            <p>{status}</p>
        </section>
    );
}
