interface Props {
    effects?: string[];
}

export default function CharacterCombatEffectPanel({ effects = [] }: Props) {
    return (
        <section>
            {effects.map((effect, index) => (
                <p key={index}>{effect}</p>
            ))}
        </section>
    );
}
