interface Props {
    level?: number;
}

export default function EquipmentUpgradePanel({ level = 0 }: Props) {
    return (
        <section>
            Upgrade Level: {level}
        </section>
    );
}
