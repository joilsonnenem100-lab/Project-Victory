interface Props {
    children?: React.ReactNode;
}

export default function EquipmentPanel({ children }: Props) {
    return (
        <section>
            {children}
        </section>
    );
}
