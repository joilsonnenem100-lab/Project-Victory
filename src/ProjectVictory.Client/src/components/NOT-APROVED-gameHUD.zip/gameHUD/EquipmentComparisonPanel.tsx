interface Props {
    current?: string;
    next?: string;
}

export default function EquipmentComparisonPanel({ current = '-', next = '-' }: Props) {
    return (
        <section>
            <p>Current: {current}</p>
            <p>New: {next}</p>
        </section>
    );
}
