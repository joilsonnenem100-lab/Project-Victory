interface Props {
    completed?: boolean;
}

export default function CharacterPlayerCombatEndPanel({ completed = false }: Props) {
    return (
        <section>
            {completed ? "Combat Finished" : "Combat Active"}
        </section>
    );
}
