interface Props {
    season?: string;
    progress?: number;
}

export default function CharacterSeasonPanel({ season = '-', progress = 0 }: Props) {
    return (
        <section>
            <p>{season}</p>
            <p>Progress: {progress}%</p>
        </section>
    );
}
