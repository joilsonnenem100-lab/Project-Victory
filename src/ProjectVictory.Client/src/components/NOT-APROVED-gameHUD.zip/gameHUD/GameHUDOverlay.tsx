import React from "react";


interface GameHUDOverlayProps
{
    children?: React.ReactNode;
}



export default function GameHUDOverlay(
{
    children

}: GameHUDOverlayProps)
{
    return (
        <div
            style={{
                position:
                    "absolute",

                top:
                    0,

                left:
                    0,

                width:
                    "100%",

                height:
                    "100%",

                pointerEvents:
                    "none"
            }}
        >

            <div
                style={{
                    pointerEvents:
                        "auto"
                }}
            >

                {children}

            </div>


        </div>
    );
}