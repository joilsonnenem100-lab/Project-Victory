interface Props {
    abilities?: { name: string; remaining: number }[];
}

export default function CharacterPlayerAbilityCooldownPanel({ abilities = [] }: Props) {
    return (
        <section>
            {abilities.map((ability, index) => (
                <p key={index}>{ability.name}: {ability.remaining}s</p>
            ))}
        </section>
    );
}
