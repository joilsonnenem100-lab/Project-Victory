interface CombatInfoPanelProps
{
    enemyName?: string;

    currentHealth?: number;

    maximumHealth?: number;

    playerHealth?: number;

    damage?: number;
}


export default function CombatInfoPanel(
{
    enemyName = "-",

    currentHealth = 0,

    maximumHealth = 0,

    playerHealth = 0,

    damage = 0

}: CombatInfoPanelProps)
{
    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "15px",

                width:
                    "100%"
            }}
        >

            <h2>
                Combat
            </h2>


            <p>
                Enemy:
                {" "}
                {enemyName}
            </p>


            <p>
                Enemy HP:
                {" "}
                {currentHealth}
                /
                {maximumHealth}
            </p>


            <p>
                Player HP:
                {" "}
                {playerHealth}
            </p>


            <p>
                Last Damage:
                {" "}
                {damage}
            </p>


        </section>
    );
}