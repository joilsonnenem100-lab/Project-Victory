interface Props {
    event?: string;
}

export default function CombatEventPanel({ event = '-' }: Props) {
    return (
        <section>
            Event: {event}
        </section>
    );
}
