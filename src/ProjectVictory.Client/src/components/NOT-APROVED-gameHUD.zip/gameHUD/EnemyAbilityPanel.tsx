interface Props {
    abilities?: string[];
}

export default function EnemyAbilityPanel({ abilities = [] }: Props) {
    return (
        <section>
            {abilities.map((ability, index) => (
                <p key={index}>{ability}</p>
            ))}
        </section>
    );
}
