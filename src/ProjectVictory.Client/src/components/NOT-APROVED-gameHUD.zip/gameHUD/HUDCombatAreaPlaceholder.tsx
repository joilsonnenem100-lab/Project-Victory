export default function HUDCombatAreaPlaceholder()
{
    return (
        <section>
            <h3>Combat Area</h3>
            <p>Reserved Area</p>
        </section>
    );
}
