interface Props {
    health?: number;
    energy?: number;
}

export default function HUDCharacterResourcesArea(
{
    health = 0,
    energy = 0

}: Props)
{
    return (
        <section>
            <h3>Resources</h3>
            <p>Health: {health}</p>
            <p>Energy: {energy}</p>
        </section>
    );
}
