interface Props {
    entries?: string[];
}

export default function CharacterCombatLogPanel({ entries = [] }: Props) {
    return (
        <section>
            {entries.map((entry, index) => (
                <p key={index}>{entry}</p>
            ))}
        </section>
    );
}
