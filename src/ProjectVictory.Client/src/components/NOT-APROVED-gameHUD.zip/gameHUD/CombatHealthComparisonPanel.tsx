interface Props {
    playerHealth?: number;
    enemyHealth?: number;
}

export default function CombatHealthComparisonPanel({playerHealth = 0, enemyHealth = 0}: Props) {
    return (
        <section>
            <p>Player HP: {playerHealth}</p>
            <p>Enemy HP: {enemyHealth}</p>
        </section>
    );
}
