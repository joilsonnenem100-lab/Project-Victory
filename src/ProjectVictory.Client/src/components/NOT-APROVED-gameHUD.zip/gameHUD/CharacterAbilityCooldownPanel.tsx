interface Props {
    abilities?: { name: string; cooldown: number }[];
}

export default function CharacterAbilityCooldownPanel({ abilities = [] }: Props) {
    return (
        <section>
            {abilities.map((ability, index) => (
                <p key={index}>{ability.name}: {ability.cooldown}s</p>
            ))}
        </section>
    );
}
