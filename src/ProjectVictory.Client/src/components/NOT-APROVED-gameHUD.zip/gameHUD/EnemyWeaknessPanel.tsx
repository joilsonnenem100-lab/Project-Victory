interface Props {
    weaknesses?: string[];
}

export default function EnemyWeaknessPanel({ weaknesses = [] }: Props) {
    return (
        <section>
            {weaknesses.map((weakness, index) => (
                <p key={index}>{weakness}</p>
            ))}
        </section>
    );
}
