interface Props {
    difficulty?: string;
}

export default function CharacterCombatDifficultyPanel({ difficulty = '-' }: Props) {
    return (
        <section>
            Difficulty: {difficulty}
        </section>
    );
}
