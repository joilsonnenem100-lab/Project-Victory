interface Props {
    enemy?: string;
    health?: number;
}

export default function CharacterCombatEnemyPanel({ enemy = '-', health = 0 }: Props) {
    return (
        <section>
            <p>Enemy: {enemy}</p>
            <p>HP: {health}</p>
        </section>
    );
}
