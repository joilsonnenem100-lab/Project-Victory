interface Props {
    name?: string;
    description?: string;
}

export default function CharacterProfilePanel({ name = '-', description = '' }: Props) {
    return (
        <section>
            <h3>{name}</h3>
            <p>{description}</p>
        </section>
    );
}
