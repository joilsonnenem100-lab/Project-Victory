interface Props {
    skills?: string[];
}

export default function CharacterPlayerSkillProgressPanel({ skills = [] }: Props) {
    return (
        <section>
            {skills.map((skill, index) => (
                <p key={index}>{skill}</p>
            ))}
        </section>
    );
}
