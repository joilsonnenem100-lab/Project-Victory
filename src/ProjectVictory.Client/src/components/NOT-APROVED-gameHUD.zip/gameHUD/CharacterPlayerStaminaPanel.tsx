interface Props {
    current?: number;
    maximum?: number;
}

export default function CharacterPlayerStaminaPanel({ current = 0, maximum = 0 }: Props) {
    return (
        <section>
            Stamina: {current}/{maximum}
        </section>
    );
}
