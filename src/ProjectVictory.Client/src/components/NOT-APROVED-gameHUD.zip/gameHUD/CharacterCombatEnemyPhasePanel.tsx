interface Props {
    phase?: string;
}

export default function CharacterCombatEnemyPhasePanel({ phase = '-' }: Props) {
    return (
        <section>
            Enemy Phase: {phase}
        </section>
    );
}
