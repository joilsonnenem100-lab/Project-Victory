import type { HUDGameState } from "./HUDGameState";

interface Props {
    state?: HUDGameState;
}

export default function HUDCenterStateArea(
{
    state = "Idle"

}: Props)
{
    return (
        <section>
            <h3>Gameplay State</h3>
            <span>{state}</span>
        </section>
    );
}
