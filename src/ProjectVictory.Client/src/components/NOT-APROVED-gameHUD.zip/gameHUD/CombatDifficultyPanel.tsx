interface Props {
    difficulty?: string;
}

export default function CombatDifficultyPanel({ difficulty = '-' }: Props) {
    return (
        <section>
            Combat Difficulty: {difficulty}
        </section>
    );
}
