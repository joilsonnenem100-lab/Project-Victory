interface Props {
    attributes?: Record<string, number>;
}

export default function CharacterCombatEnemyAttributePanel({ attributes = {} }: Props) {
    return (
        <section>
            {Object.entries(attributes).map(([key, value]) => (
                <p key={key}>{key}: {value}</p>
            ))}
        </section>
    );
}
