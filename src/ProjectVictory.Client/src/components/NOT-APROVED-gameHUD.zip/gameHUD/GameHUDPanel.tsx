import React from "react";


interface GameHUDPanelProps
{
    title?: string;

    children?: React.ReactNode;
}



export default function GameHUDPanel(
{
    title,

    children

}: GameHUDPanelProps)
{
    return (
        <section
            style={{
                border:
                    "1px solid #444",

                padding:
                    "10px",

                background:
                    "#111",

                width:
                    "100%"
            }}
        >

            {
                title &&

                <h3>
                    {title}
                </h3>
            }



            <div>
                {children}
            </div>


        </section>
    );
}