interface Props {
    victories?: number;
    defeats?: number;
}

export default function CharacterPlayerPerformancePanel({ victories = 0, defeats = 0 }: Props) {
    return (
        <section>
            <p>Victories: {victories}</p>
            <p>Defeats: {defeats}</p>
        </section>
    );
}
