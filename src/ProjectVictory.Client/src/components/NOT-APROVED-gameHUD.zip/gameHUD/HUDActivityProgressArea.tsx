interface Props {
    progress?: number;
}

export default function HUDActivityProgressArea(
{
    progress = 0

}: Props)
{
    return (
        <section>
            <h3>Activity Progress</h3>
            <p>{progress}%</p>
        </section>
    );
}
