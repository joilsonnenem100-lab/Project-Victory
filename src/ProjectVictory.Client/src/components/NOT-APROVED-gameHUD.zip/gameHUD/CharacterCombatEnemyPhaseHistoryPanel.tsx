interface Props {
    phases?: string[];
}

export default function CharacterCombatEnemyPhaseHistoryPanel({ phases = [] }: Props) {
    return (
        <section>
            {phases.map((phase, index) => (
                <p key={index}>{phase}</p>
            ))}
        </section>
    );
}
