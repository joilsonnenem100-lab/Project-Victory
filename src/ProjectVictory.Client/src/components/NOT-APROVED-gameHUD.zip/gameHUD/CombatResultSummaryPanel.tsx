interface Props {
    result?: string;
    rewards?: number;
}

export default function CombatResultSummaryPanel({result = "-", rewards = 0}: Props) {
    return (
        <section>
            <p>{result}</p>
            <p>Rewards: {rewards}</p>
        </section>
    );
}
