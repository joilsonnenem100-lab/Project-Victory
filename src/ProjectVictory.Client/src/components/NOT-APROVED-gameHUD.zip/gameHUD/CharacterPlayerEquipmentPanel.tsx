interface Props {
    items?: string[];
}

export default function CharacterPlayerEquipmentPanel({ items = [] }: Props) {
    return (
        <section>
            {items.map((item, index) => (
                <p key={index}>{item}</p>
            ))}
        </section>
    );
}
