export default function HUDHuntAreaPlaceholder()
{
    return (
        <section>
            <h3>Hunt Area</h3>
            <p>Reserved Area</p>
        </section>
    );
}
