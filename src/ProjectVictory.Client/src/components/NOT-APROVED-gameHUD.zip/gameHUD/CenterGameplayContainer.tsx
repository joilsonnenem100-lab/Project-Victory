import React from "react";


interface CenterGameplayContainerProps
{
    children?: React.ReactNode;
}



export default function CenterGameplayContainer(
{
    children

}: CenterGameplayContainerProps)
{
    return (
        <section
            style={{
                display:
                    "flex",

                flexDirection:
                    "column",

                justifyContent:
                    "center",

                alignItems:
                    "center",

                border:
                    "1px solid #444",

                padding:
                    "20px",

                minHeight:
                    "400px",

                width:
                    "100%"
            }}
        >

            {
                children

                ?

                children

                :

                (
                    <p>
                        Gameplay Area
                    </p>
                )
            }


        </section>
    );
}