interface Props {
    status?: string;
}

export default function EnemyCombatStatusPanel({ status = '-' }: Props) {
    return (
        <section>
            Combat Status: {status}
        </section>
    );
}
