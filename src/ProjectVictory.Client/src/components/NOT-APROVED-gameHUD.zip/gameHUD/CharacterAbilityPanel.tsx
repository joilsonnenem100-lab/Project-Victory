interface Props {
    abilities?: string[];
}

export default function CharacterAbilityPanel({ abilities = [] }: Props) {
    return (
        <section>
            {abilities.map((ability, index) => (
                <button key={index}>{ability}</button>
            ))}
        </section>
    );
}
