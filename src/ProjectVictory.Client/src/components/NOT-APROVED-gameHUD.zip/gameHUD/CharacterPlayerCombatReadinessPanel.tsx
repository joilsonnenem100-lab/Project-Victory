interface Props {
    ready?: boolean;
    status?: string;
}

export default function CharacterPlayerCombatReadinessPanel({ ready = false, status = '-' }: Props) {
    return (
        <section>
            <p>{ready ? "Ready" : "Not Ready"}</p>
            <p>Status: {status}</p>
        </section>
    );
}
