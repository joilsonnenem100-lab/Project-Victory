interface Props {
    summary?: string;
}

export default function CombatResolutionSummaryPanel({ summary = '-' }: Props) {
    return (
        <section>
            Resolution: {summary}
        </section>
    );
}
