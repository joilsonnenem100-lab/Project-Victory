interface Props {
    category?: string;
}

export default function EnemyCategoryPanel({ category = '-' }: Props) {
    return (
        <section>
            Category: {category}
        </section>
    );
}
