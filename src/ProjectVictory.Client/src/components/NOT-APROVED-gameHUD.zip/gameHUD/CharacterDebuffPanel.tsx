interface Props {
    debuffs?: string[];
}

export default function CharacterDebuffPanel({ debuffs = [] }: Props) {
    return (
        <section>
            {debuffs.map((debuff, index) => (
                <p key={index}>{debuff}</p>
            ))}
        </section>
    );
}
